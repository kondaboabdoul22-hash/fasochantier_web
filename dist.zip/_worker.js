var Ft=Object.defineProperty;var Qe=e=>{throw TypeError(e)};var It=(e,t,s)=>t in e?Ft(e,t,{enumerable:!0,configurable:!0,writable:!0,value:s}):e[t]=s;var h=(e,t,s)=>It(e,typeof t!="symbol"?t+"":t,s),Ve=(e,t,s)=>t.has(e)||Qe("Cannot "+s);var o=(e,t,s)=>(Ve(e,t,"read from private field"),s?s.call(e):t.get(e)),v=(e,t,s)=>t.has(e)?Qe("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,s),x=(e,t,s,a)=>(Ve(e,t,"write to private field"),a?a.call(e,s):t.set(e,s),s),b=(e,t,s)=>(Ve(e,t,"access private method"),s);var et=(e,t,s,a)=>({set _(i){x(e,t,i,s)},get _(){return o(e,t,a)}});var tt=(e,t,s)=>(a,i)=>{let r=-1;return n(0);async function n(l){if(l<=r)throw new Error("next() called multiple times");r=l;let c,d=!1,u;if(e[l]?(u=e[l][0][0],a.req.routeIndex=l):u=l===e.length&&i||void 0,u)try{c=await u(a,()=>n(l+1))}catch(p){if(p instanceof Error&&t)a.error=p,c=await t(p,a),d=!0;else throw p}else a.finalized===!1&&s&&(c=await s(a));return c&&(a.finalized===!1||d)&&(a.res=c),a}},Dt=Symbol(),Lt=async(e,t=Object.create(null))=>{const{all:s=!1,dot:a=!1}=t,r=(e instanceof bt?e.raw.headers:e.headers).get("Content-Type");return r!=null&&r.startsWith("multipart/form-data")||r!=null&&r.startsWith("application/x-www-form-urlencoded")?Nt(e,{all:s,dot:a}):{}};async function Nt(e,t){const s=await e.formData();return s?Bt(s,t):{}}function Bt(e,t){const s=Object.create(null);return e.forEach((a,i)=>{t.all||i.endsWith("[]")?Ut(s,i,a):s[i]=a}),t.dot&&Object.entries(s).forEach(([a,i])=>{a.includes(".")&&(qt(s,a,i),delete s[a])}),s}var Ut=(e,t,s)=>{e[t]!==void 0?Array.isArray(e[t])?e[t].push(s):e[t]=[e[t],s]:t.endsWith("[]")?e[t]=[s]:e[t]=s},qt=(e,t,s)=>{if(/(?:^|\.)__proto__\./.test(t))return;let a=e;const i=t.split(".");i.forEach((r,n)=>{n===i.length-1?a[r]=s:((!a[r]||typeof a[r]!="object"||Array.isArray(a[r])||a[r]instanceof File)&&(a[r]=Object.create(null)),a=a[r])})},xt=e=>{const t=e.split("/");return t[0]===""&&t.shift(),t},Ht=e=>{const{groups:t,path:s}=zt(e),a=xt(s);return Vt(a,t)},zt=e=>{const t=[];return e=e.replace(/\{[^}]+\}/g,(s,a)=>{const i=`@${a}`;return t.push([i,s]),i}),{groups:t,path:e}},Vt=(e,t)=>{for(let s=t.length-1;s>=0;s--){const[a]=t[s];for(let i=e.length-1;i>=0;i--)if(e[i].includes(a)){e[i]=e[i].replace(a,t[s][1]);break}}return e},Fe={},Gt=(e,t)=>{if(e==="*")return"*";const s=e.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);if(s){const a=`${e}#${t}`;return Fe[a]||(s[2]?Fe[a]=t&&t[0]!==":"&&t[0]!=="*"?[a,s[1],new RegExp(`^${s[2]}(?=/${t})`)]:[e,s[1],new RegExp(`^${s[2]}$`)]:Fe[a]=[e,s[1],!0]),Fe[a]}return null},qe=(e,t)=>{try{return t(e)}catch{return e.replace(/(?:%[0-9A-Fa-f]{2})+/g,s=>{try{return t(s)}catch{return s}})}},ht=e=>qe(e,decodeURI),vt=e=>{const t=e.url,s=t.indexOf("/",t.indexOf(":")+4);let a=s;for(;a<t.length;a++){const i=t.charCodeAt(a);if(i===37){const r=t.indexOf("?",a),n=t.indexOf("#",a),l=r===-1?n===-1?void 0:n:n===-1?r:Math.min(r,n),c=t.slice(s,l);return ht(c.includes("%25")?c.replace(/%25/g,"%2525"):c)}else if(i===63||i===35)break}return t.slice(s,a)},Kt=e=>{const t=vt(e);return t.length>1&&t.at(-1)==="/"?t.slice(0,-1):t},pe=(e,t,...s)=>(s.length&&(t=pe(t,...s)),`${(e==null?void 0:e[0])==="/"?"":"/"}${e}${t==="/"?"":`${(e==null?void 0:e.at(-1))==="/"?"":"/"}${(t==null?void 0:t[0])==="/"?t.slice(1):t}`}`),mt=e=>{if(e.charCodeAt(e.length-1)!==63||!e.includes(":"))return null;const t=e.split("/"),s=[];let a="";return t.forEach(i=>{if(i!==""&&!/\:/.test(i))a+="/"+i;else if(/\:/.test(i))if(/\?/.test(i)){s.length===0&&a===""?s.push("/"):s.push(a);const r=i.replace("?","");a+="/"+r,s.push(a)}else a+="/"+i}),s.filter((i,r,n)=>n.indexOf(i)===r)},Ge=e=>/[%+]/.test(e)?(e.indexOf("+")!==-1&&(e=e.replace(/\+/g," ")),e.indexOf("%")!==-1?qe(e,Ye):e):e,gt=(e,t,s)=>{let a;if(!s&&t&&!/[%+]/.test(t)){let n=e.indexOf("?",8);if(n===-1)return;for(e.startsWith(t,n+1)||(n=e.indexOf(`&${t}`,n+1));n!==-1;){const l=e.charCodeAt(n+t.length+1);if(l===61){const c=n+t.length+2,d=e.indexOf("&",c);return Ge(e.slice(c,d===-1?void 0:d))}else if(l==38||isNaN(l))return"";n=e.indexOf(`&${t}`,n+1)}if(a=/[%+]/.test(e),!a)return}const i={};a??(a=/[%+]/.test(e));let r=e.indexOf("?",8);for(;r!==-1;){const n=e.indexOf("&",r+1);let l=e.indexOf("=",r);l>n&&n!==-1&&(l=-1);let c=e.slice(r+1,l===-1?n===-1?void 0:n:l);if(a&&(c=Ge(c)),r=n,c==="")continue;let d;l===-1?d="":(d=e.slice(l+1,n===-1?void 0:n),a&&(d=Ge(d))),s?(i[c]&&Array.isArray(i[c])||(i[c]=[]),i[c].push(d)):i[c]??(i[c]=d)}return t?i[t]:i},Wt=gt,Jt=(e,t)=>gt(e,t,!0),Ye=decodeURIComponent,st=e=>qe(e,Ye),he,F,K,yt,wt,Je,J,ot,bt=(ot=class{constructor(e,t="/",s=[[]]){v(this,K);h(this,"raw");v(this,he);v(this,F);h(this,"routeIndex",0);h(this,"path");h(this,"bodyCache",{});v(this,J,e=>{const{bodyCache:t,raw:s}=this,a=t[e];if(a)return a;const i=Object.keys(t)[0];return i?t[i].then(r=>(i==="json"&&(r=JSON.stringify(r)),new Response(r)[e]())):t[e]=s[e]()});this.raw=e,this.path=t,x(this,F,s),x(this,he,{})}param(e){return e?b(this,K,yt).call(this,e):b(this,K,wt).call(this)}query(e){return Wt(this.url,e)}queries(e){return Jt(this.url,e)}header(e){if(e)return this.raw.headers.get(e)??void 0;const t={};return this.raw.headers.forEach((s,a)=>{t[a]=s}),t}async parseBody(e){return Lt(this,e)}json(){return o(this,J).call(this,"text").then(e=>JSON.parse(e))}text(){return o(this,J).call(this,"text")}arrayBuffer(){return o(this,J).call(this,"arrayBuffer")}blob(){return o(this,J).call(this,"blob")}formData(){return o(this,J).call(this,"formData")}addValidatedData(e,t){o(this,he)[e]=t}valid(e){return o(this,he)[e]}get url(){return this.raw.url}get method(){return this.raw.method}get[Dt](){return o(this,F)}get matchedRoutes(){return o(this,F)[0].map(([[,e]])=>e)}get routePath(){return o(this,F)[0].map(([[,e]])=>e)[this.routeIndex].path}},he=new WeakMap,F=new WeakMap,K=new WeakSet,yt=function(e){const t=o(this,F)[0][this.routeIndex][1][e],s=b(this,K,Je).call(this,t);return s&&/\%/.test(s)?st(s):s},wt=function(){const e={},t=Object.keys(o(this,F)[0][this.routeIndex][1]);for(const s of t){const a=b(this,K,Je).call(this,o(this,F)[0][this.routeIndex][1][s]);a!==void 0&&(e[s]=/\%/.test(a)?st(a):a)}return e},Je=function(e){return o(this,F)[1]?o(this,F)[1][e]:e},J=new WeakMap,ot),Yt={Stringify:1},kt=async(e,t,s,a,i)=>{typeof e=="object"&&!(e instanceof String)&&(e instanceof Promise||(e=e.toString()),e instanceof Promise&&(e=await e));const r=e.callbacks;return r!=null&&r.length?(i?i[0]+=e:i=[e],Promise.all(r.map(l=>l({phase:t,buffer:i,context:a}))).then(l=>Promise.all(l.filter(Boolean).map(c=>kt(c,t,!1,a,i))).then(()=>i[0]))):Promise.resolve(e)},Zt="text/plain; charset=UTF-8",Ke=(e,t)=>({"Content-Type":e,...t}),Ae=(e,t)=>new Response(e,t),Se,Re,q,ve,H,T,Te,me,ge,ae,_e,Me,Y,fe,ct,Xt=(ct=class{constructor(e,t){v(this,Y);v(this,Se);v(this,Re);h(this,"env",{});v(this,q);h(this,"finalized",!1);h(this,"error");v(this,ve);v(this,H);v(this,T);v(this,Te);v(this,me);v(this,ge);v(this,ae);v(this,_e);v(this,Me);h(this,"render",(...e)=>(o(this,me)??x(this,me,t=>this.html(t)),o(this,me).call(this,...e)));h(this,"setLayout",e=>x(this,Te,e));h(this,"getLayout",()=>o(this,Te));h(this,"setRenderer",e=>{x(this,me,e)});h(this,"header",(e,t,s)=>{this.finalized&&x(this,T,Ae(o(this,T).body,o(this,T)));const a=o(this,T)?o(this,T).headers:o(this,ae)??x(this,ae,new Headers);t===void 0?a.delete(e):s!=null&&s.append?a.append(e,t):a.set(e,t)});h(this,"status",e=>{x(this,ve,e)});h(this,"set",(e,t)=>{o(this,q)??x(this,q,new Map),o(this,q).set(e,t)});h(this,"get",e=>o(this,q)?o(this,q).get(e):void 0);h(this,"newResponse",(...e)=>b(this,Y,fe).call(this,...e));h(this,"body",(e,t,s)=>b(this,Y,fe).call(this,e,t,s));h(this,"text",(e,t,s)=>!o(this,ae)&&!o(this,ve)&&!t&&!s&&!this.finalized?new Response(e):b(this,Y,fe).call(this,e,t,Ke(Zt,s)));h(this,"json",(e,t,s)=>b(this,Y,fe).call(this,JSON.stringify(e),t,Ke("application/json",s)));h(this,"html",(e,t,s)=>{const a=i=>b(this,Y,fe).call(this,i,t,Ke("text/html; charset=UTF-8",s));return typeof e=="object"?kt(e,Yt.Stringify,!1,{}).then(a):a(e)});h(this,"redirect",(e,t)=>{const s=String(e);return this.header("Location",/[^\x00-\xFF]/.test(s)?encodeURI(s):s),this.newResponse(null,t??302)});h(this,"notFound",()=>(o(this,ge)??x(this,ge,()=>Ae()),o(this,ge).call(this,this)));x(this,Se,e),t&&(x(this,H,t.executionCtx),this.env=t.env,x(this,ge,t.notFoundHandler),x(this,Me,t.path),x(this,_e,t.matchResult))}get req(){return o(this,Re)??x(this,Re,new bt(o(this,Se),o(this,Me),o(this,_e))),o(this,Re)}get event(){if(o(this,H)&&"respondWith"in o(this,H))return o(this,H);throw Error("This context has no FetchEvent")}get executionCtx(){if(o(this,H))return o(this,H);throw Error("This context has no ExecutionContext")}get res(){return o(this,T)||x(this,T,Ae(null,{headers:o(this,ae)??x(this,ae,new Headers)}))}set res(e){if(o(this,T)&&e){e=Ae(e.body,e);for(const[t,s]of o(this,T).headers.entries())if(t!=="content-type")if(t==="set-cookie"){const a=o(this,T).headers.getSetCookie();e.headers.delete("set-cookie");for(const i of a)e.headers.append("set-cookie",i)}else e.headers.set(t,s)}x(this,T,e),this.finalized=!0}get var(){return o(this,q)?Object.fromEntries(o(this,q)):{}}},Se=new WeakMap,Re=new WeakMap,q=new WeakMap,ve=new WeakMap,H=new WeakMap,T=new WeakMap,Te=new WeakMap,me=new WeakMap,ge=new WeakMap,ae=new WeakMap,_e=new WeakMap,Me=new WeakMap,Y=new WeakSet,fe=function(e,t,s){const a=o(this,T)?new Headers(o(this,T).headers):o(this,ae)??new Headers;if(typeof t=="object"&&"headers"in t){const r=t.headers instanceof Headers?t.headers:new Headers(t.headers);for(const[n,l]of r)n.toLowerCase()==="set-cookie"?a.append(n,l):a.set(n,l)}if(s)for(const[r,n]of Object.entries(s))if(typeof n=="string")a.set(r,n);else{a.delete(r);for(const l of n)a.append(r,l)}const i=typeof t=="number"?t:(t==null?void 0:t.status)??o(this,ve);return Ae(e,{status:i,headers:a})},ct),j="ALL",Qt="all",es=["get","post","put","delete","options","patch"],$t="Can not add a route since the matcher is already built.",jt=class extends Error{},ts="__COMPOSED_HANDLER",ss=e=>e.text("404 Not Found",404),at=(e,t)=>{if("getResponse"in e){const s=e.getResponse();return t.newResponse(s.body,s)}return console.error(e),t.text("Internal Server Error",500)},L,A,At,N,te,Ie,De,be,as=(be=class{constructor(t={}){v(this,A);h(this,"get");h(this,"post");h(this,"put");h(this,"delete");h(this,"options");h(this,"patch");h(this,"all");h(this,"on");h(this,"use");h(this,"router");h(this,"getPath");h(this,"_basePath","/");v(this,L,"/");h(this,"routes",[]);v(this,N,ss);h(this,"errorHandler",at);h(this,"onError",t=>(this.errorHandler=t,this));h(this,"notFound",t=>(x(this,N,t),this));h(this,"fetch",(t,...s)=>b(this,A,De).call(this,t,s[1],s[0],t.method));h(this,"request",(t,s,a,i)=>t instanceof Request?this.fetch(s?new Request(t,s):t,a,i):(t=t.toString(),this.fetch(new Request(/^https?:\/\//.test(t)?t:`http://localhost${pe("/",t)}`,s),a,i)));h(this,"fire",()=>{addEventListener("fetch",t=>{t.respondWith(b(this,A,De).call(this,t.request,t,void 0,t.request.method))})});[...es,Qt].forEach(r=>{this[r]=(n,...l)=>(typeof n=="string"?x(this,L,n):b(this,A,te).call(this,r,o(this,L),n),l.forEach(c=>{b(this,A,te).call(this,r,o(this,L),c)}),this)}),this.on=(r,n,...l)=>{for(const c of[n].flat()){x(this,L,c);for(const d of[r].flat())l.map(u=>{b(this,A,te).call(this,d.toUpperCase(),o(this,L),u)})}return this},this.use=(r,...n)=>(typeof r=="string"?x(this,L,r):(x(this,L,"*"),n.unshift(r)),n.forEach(l=>{b(this,A,te).call(this,j,o(this,L),l)}),this);const{strict:a,...i}=t;Object.assign(this,i),this.getPath=a??!0?t.getPath??vt:Kt}route(t,s){const a=this.basePath(t);return s.routes.map(i=>{var n;let r;s.errorHandler===at?r=i.handler:(r=async(l,c)=>(await tt([],s.errorHandler)(l,()=>i.handler(l,c))).res,r[ts]=i.handler),b(n=a,A,te).call(n,i.method,i.path,r)}),this}basePath(t){const s=b(this,A,At).call(this);return s._basePath=pe(this._basePath,t),s}mount(t,s,a){let i,r;a&&(typeof a=="function"?r=a:(r=a.optionHandler,a.replaceRequest===!1?i=c=>c:i=a.replaceRequest));const n=r?c=>{const d=r(c);return Array.isArray(d)?d:[d]}:c=>{let d;try{d=c.executionCtx}catch{}return[c.env,d]};i||(i=(()=>{const c=pe(this._basePath,t),d=c==="/"?0:c.length;return u=>{const p=new URL(u.url);return p.pathname=p.pathname.slice(d)||"/",new Request(p,u)}})());const l=async(c,d)=>{const u=await s(i(c.req.raw),...n(c));if(u)return u;await d()};return b(this,A,te).call(this,j,pe(t,"*"),l),this}},L=new WeakMap,A=new WeakSet,At=function(){const t=new be({router:this.router,getPath:this.getPath});return t.errorHandler=this.errorHandler,x(t,N,o(this,N)),t.routes=this.routes,t},N=new WeakMap,te=function(t,s,a){t=t.toUpperCase(),s=pe(this._basePath,s);const i={basePath:this._basePath,path:s,method:t,handler:a};this.router.add(t,s,[a,i]),this.routes.push(i)},Ie=function(t,s){if(t instanceof Error)return this.errorHandler(t,s);throw t},De=function(t,s,a,i){if(i==="HEAD")return(async()=>new Response(null,await b(this,A,De).call(this,t,s,a,"GET")))();const r=this.getPath(t,{env:a}),n=this.router.match(i,r),l=new Xt(t,{path:r,matchResult:n,env:a,executionCtx:s,notFoundHandler:o(this,N)});if(n[0].length===1){let d;try{d=n[0][0][0][0](l,async()=>{l.res=await o(this,N).call(this,l)})}catch(u){return b(this,A,Ie).call(this,u,l)}return d instanceof Promise?d.then(u=>u||(l.finalized?l.res:o(this,N).call(this,l))).catch(u=>b(this,A,Ie).call(this,u,l)):d??o(this,N).call(this,l)}const c=tt(n[0],this.errorHandler,o(this,N));return(async()=>{try{const d=await c(l);if(!d.finalized)throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");return d.res}catch(d){return b(this,A,Ie).call(this,d,l)}})()},be),Ct=[];function is(e,t){const s=this.buildAllMatchers(),a=((i,r)=>{const n=s[i]||s[j],l=n[2][r];if(l)return l;const c=r.match(n[0]);if(!c)return[[],Ct];const d=c.indexOf("",1);return[n[1][d],c]});return this.match=a,a(e,t)}var Ne="[^/]+",Ee=".*",Pe="(?:|/.*)",xe=Symbol(),rs=new Set(".\\+*[^]$()");function ns(e,t){return e.length===1?t.length===1?e<t?-1:1:-1:t.length===1||e===Ee||e===Pe?1:t===Ee||t===Pe?-1:e===Ne?1:t===Ne?-1:e.length===t.length?e<t?-1:1:t.length-e.length}var ie,re,B,oe,ls=(oe=class{constructor(){v(this,ie);v(this,re);v(this,B,Object.create(null))}insert(t,s,a,i,r){if(t.length===0){if(o(this,ie)!==void 0)throw xe;if(r)return;x(this,ie,s);return}const[n,...l]=t,c=n==="*"?l.length===0?["","",Ee]:["","",Ne]:n==="/*"?["","",Pe]:n.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);let d;if(c){const u=c[1];let p=c[2]||Ne;if(u&&c[2]&&(p===".*"||(p=p.replace(/^\((?!\?:)(?=[^)]+\)$)/,"(?:"),/\((?!\?:)/.test(p))))throw xe;if(d=o(this,B)[p],!d){if(Object.keys(o(this,B)).some(f=>f!==Ee&&f!==Pe))throw xe;if(r)return;d=o(this,B)[p]=new oe,u!==""&&x(d,re,i.varIndex++)}!r&&u!==""&&a.push([u,o(d,re)])}else if(d=o(this,B)[n],!d){if(Object.keys(o(this,B)).some(u=>u.length>1&&u!==Ee&&u!==Pe))throw xe;if(r)return;d=o(this,B)[n]=new oe}d.insert(l,s,a,i,r)}buildRegExpStr(){const s=Object.keys(o(this,B)).sort(ns).map(a=>{const i=o(this,B)[a];return(typeof o(i,re)=="number"?`(${a})@${o(i,re)}`:rs.has(a)?`\\${a}`:a)+i.buildRegExpStr()});return typeof o(this,ie)=="number"&&s.unshift(`#${o(this,ie)}`),s.length===0?"":s.length===1?s[0]:"(?:"+s.join("|")+")"}},ie=new WeakMap,re=new WeakMap,B=new WeakMap,oe),Be,Oe,dt,os=(dt=class{constructor(){v(this,Be,{varIndex:0});v(this,Oe,new ls)}insert(e,t,s){const a=[],i=[];for(let n=0;;){let l=!1;if(e=e.replace(/\{[^}]+\}/g,c=>{const d=`@\\${n}`;return i[n]=[d,c],n++,l=!0,d}),!l)break}const r=e.match(/(?::[^\/]+)|(?:\/\*$)|./g)||[];for(let n=i.length-1;n>=0;n--){const[l]=i[n];for(let c=r.length-1;c>=0;c--)if(r[c].indexOf(l)!==-1){r[c]=r[c].replace(l,i[n][1]);break}}return o(this,Oe).insert(r,t,a,o(this,Be),s),a}buildRegExp(){let e=o(this,Oe).buildRegExpStr();if(e==="")return[/^$/,[],[]];let t=0;const s=[],a=[];return e=e.replace(/#(\d+)|@(\d+)|\.\*\$/g,(i,r,n)=>r!==void 0?(s[++t]=Number(r),"$()"):(n!==void 0&&(a[Number(n)]=++t),"")),[new RegExp(`^${e}`),s,a]}},Be=new WeakMap,Oe=new WeakMap,dt),cs=[/^$/,[],Object.create(null)],Le=Object.create(null);function Et(e){return Le[e]??(Le[e]=new RegExp(e==="*"?"":`^${e.replace(/\/\*$|([.\\+*[^\]$()])/g,(t,s)=>s?`\\${s}`:"(?:|/.*)")}$`))}function ds(){Le=Object.create(null)}function us(e){var d;const t=new os,s=[];if(e.length===0)return cs;const a=e.map(u=>[!/\*|\/:/.test(u[0]),...u]).sort(([u,p],[f,m])=>u?1:f?-1:p.length-m.length),i=Object.create(null);for(let u=0,p=-1,f=a.length;u<f;u++){const[m,g,k]=a[u];m?i[g]=[k.map(([P])=>[P,Object.create(null)]),Ct]:p++;let $;try{$=t.insert(g,p,m)}catch(P){throw P===xe?new jt(g):P}m||(s[p]=k.map(([P,w])=>{const R=Object.create(null);for(w-=1;w>=0;w--){const[ke,He]=$[w];R[ke]=He}return[P,R]}))}const[r,n,l]=t.buildRegExp();for(let u=0,p=s.length;u<p;u++)for(let f=0,m=s[u].length;f<m;f++){const g=(d=s[u][f])==null?void 0:d[1];if(!g)continue;const k=Object.keys(g);for(let $=0,P=k.length;$<P;$++)g[k[$]]=l[g[k[$]]]}const c=[];for(const u in n)c[u]=s[n[u]];return[r,c,i]}function ue(e,t){if(e){for(const s of Object.keys(e).sort((a,i)=>i.length-a.length))if(Et(s).test(t))return[...e[s]]}}var Z,X,Ue,Pt,ut,ps=(ut=class{constructor(){v(this,Ue);h(this,"name","RegExpRouter");v(this,Z);v(this,X);h(this,"match",is);x(this,Z,{[j]:Object.create(null)}),x(this,X,{[j]:Object.create(null)})}add(e,t,s){var l;const a=o(this,Z),i=o(this,X);if(!a||!i)throw new Error($t);a[e]||[a,i].forEach(c=>{c[e]=Object.create(null),Object.keys(c[j]).forEach(d=>{c[e][d]=[...c[j][d]]})}),t==="/*"&&(t="*");const r=(t.match(/\/:/g)||[]).length;if(/\*$/.test(t)){const c=Et(t);e===j?Object.keys(a).forEach(d=>{var u;(u=a[d])[t]||(u[t]=ue(a[d],t)||ue(a[j],t)||[])}):(l=a[e])[t]||(l[t]=ue(a[e],t)||ue(a[j],t)||[]),Object.keys(a).forEach(d=>{(e===j||e===d)&&Object.keys(a[d]).forEach(u=>{c.test(u)&&a[d][u].push([s,r])})}),Object.keys(i).forEach(d=>{(e===j||e===d)&&Object.keys(i[d]).forEach(u=>c.test(u)&&i[d][u].push([s,r]))});return}const n=mt(t)||[t];for(let c=0,d=n.length;c<d;c++){const u=n[c];Object.keys(i).forEach(p=>{var f;(e===j||e===p)&&((f=i[p])[u]||(f[u]=[...ue(a[p],u)||ue(a[j],u)||[]]),i[p][u].push([s,r-d+c+1]))})}}buildAllMatchers(){const e=Object.create(null);return Object.keys(o(this,X)).concat(Object.keys(o(this,Z))).forEach(t=>{e[t]||(e[t]=b(this,Ue,Pt).call(this,t))}),x(this,Z,x(this,X,void 0)),ds(),e}},Z=new WeakMap,X=new WeakMap,Ue=new WeakSet,Pt=function(e){const t=[];let s=e===j;return[o(this,Z),o(this,X)].forEach(a=>{const i=a[e]?Object.keys(a[e]).map(r=>[r,a[e][r]]):[];i.length!==0?(s||(s=!0),t.push(...i)):e!==j&&t.push(...Object.keys(a[j]).map(r=>[r,a[j][r]]))}),s?us(t):null},ut),Q,z,pt,fs=(pt=class{constructor(e){h(this,"name","SmartRouter");v(this,Q,[]);v(this,z,[]);x(this,Q,e.routers)}add(e,t,s){if(!o(this,z))throw new Error($t);o(this,z).push([e,t,s])}match(e,t){if(!o(this,z))throw new Error("Fatal error");const s=o(this,Q),a=o(this,z),i=s.length;let r=0,n;for(;r<i;r++){const l=s[r];try{for(let c=0,d=a.length;c<d;c++)l.add(...a[c]);n=l.match(e,t)}catch(c){if(c instanceof jt)continue;throw c}this.match=l.match.bind(l),x(this,Q,[l]),x(this,z,void 0);break}if(r===i)throw new Error("Fatal error");return this.name=`SmartRouter + ${this.activeRouter.name}`,n}get activeRouter(){if(o(this,z)||o(this,Q).length!==1)throw new Error("No active router has been determined yet.");return o(this,Q)[0]}},Q=new WeakMap,z=new WeakMap,pt),Ce=Object.create(null),xs=e=>{for(const t in e)return!0;return!1},ee,S,ne,ye,C,V,se,we,hs=(we=class{constructor(t,s,a){v(this,V);v(this,ee);v(this,S);v(this,ne);v(this,ye,0);v(this,C,Ce);if(x(this,S,a||Object.create(null)),x(this,ee,[]),t&&s){const i=Object.create(null);i[t]={handler:s,possibleKeys:[],score:0},x(this,ee,[i])}x(this,ne,[])}insert(t,s,a){x(this,ye,++et(this,ye)._);let i=this;const r=Ht(s),n=[];for(let l=0,c=r.length;l<c;l++){const d=r[l],u=r[l+1],p=Gt(d,u),f=Array.isArray(p)?p[0]:d;if(f in o(i,S)){i=o(i,S)[f],p&&n.push(p[1]);continue}o(i,S)[f]=new we,p&&(o(i,ne).push(p),n.push(p[1])),i=o(i,S)[f]}return o(i,ee).push({[t]:{handler:a,possibleKeys:n.filter((l,c,d)=>d.indexOf(l)===c),score:o(this,ye)}}),i}search(t,s){var u;const a=[];x(this,C,Ce);let r=[this];const n=xt(s),l=[],c=n.length;let d=null;for(let p=0;p<c;p++){const f=n[p],m=p===c-1,g=[];for(let $=0,P=r.length;$<P;$++){const w=r[$],R=o(w,S)[f];R&&(x(R,C,o(w,C)),m?(o(R,S)["*"]&&b(this,V,se).call(this,a,o(R,S)["*"],t,o(w,C)),b(this,V,se).call(this,a,R,t,o(w,C))):g.push(R));for(let ke=0,He=o(w,ne).length;ke<He;ke++){const Ze=o(w,ne)[ke],W=o(w,C)===Ce?{}:{...o(w,C)};if(Ze==="*"){const ce=o(w,S)["*"];ce&&(b(this,V,se).call(this,a,ce,t,o(w,C)),x(ce,C,W),g.push(ce));continue}const[Ot,Xe,$e]=Ze;if(!f&&!($e instanceof RegExp))continue;const U=o(w,S)[Ot];if($e instanceof RegExp){if(d===null){d=new Array(c);let de=s[0]==="/"?1:0;for(let je=0;je<c;je++)d[je]=de,de+=n[je].length+1}const ce=s.substring(d[p]),ze=$e.exec(ce);if(ze){if(W[Xe]=ze[0],b(this,V,se).call(this,a,U,t,o(w,C),W),xs(o(U,S))){x(U,C,W);const de=((u=ze[0].match(/\//))==null?void 0:u.length)??0;(l[de]||(l[de]=[])).push(U)}continue}}($e===!0||$e.test(f))&&(W[Xe]=f,m?(b(this,V,se).call(this,a,U,t,W,o(w,C)),o(U,S)["*"]&&b(this,V,se).call(this,a,o(U,S)["*"],t,W,o(w,C))):(x(U,C,W),g.push(U)))}}const k=l.shift();r=k?g.concat(k):g}return a.length>1&&a.sort((p,f)=>p.score-f.score),[a.map(({handler:p,params:f})=>[p,f])]}},ee=new WeakMap,S=new WeakMap,ne=new WeakMap,ye=new WeakMap,C=new WeakMap,V=new WeakSet,se=function(t,s,a,i,r){for(let n=0,l=o(s,ee).length;n<l;n++){const c=o(s,ee)[n],d=c[a]||c[j],u={};if(d!==void 0&&(d.params=Object.create(null),t.push(d),i!==Ce||r&&r!==Ce))for(let p=0,f=d.possibleKeys.length;p<f;p++){const m=d.possibleKeys[p],g=u[d.score];d.params[m]=r!=null&&r[m]&&!g?r[m]:i[m]??(r==null?void 0:r[m]),u[d.score]=!0}}},we),le,ft,vs=(ft=class{constructor(){h(this,"name","TrieRouter");v(this,le);x(this,le,new hs)}add(e,t,s){const a=mt(t);if(a){for(let i=0,r=a.length;i<r;i++)o(this,le).insert(e,a[i],s);return}o(this,le).insert(e,t,s)}match(e,t){return o(this,le).search(e,t)}},le=new WeakMap,ft),St=class extends as{constructor(e={}){super(e),this.router=e.router??new fs({routers:[new ps,new vs]})}},ms=/^\s*(?:text\/(?!event-stream(?:[;\s]|$))[^;\s]+|application\/(?:javascript|json|xml|xml-dtd|ecmascript|dart|postscript|rtf|tar|toml|vnd\.dart|vnd\.ms-fontobject|vnd\.ms-opentype|wasm|x-httpd-php|x-javascript|x-ns-proxy-autoconfig|x-sh|x-tar|x-virtualbox-hdd|x-virtualbox-ova|x-virtualbox-ovf|x-virtualbox-vbox|x-virtualbox-vdi|x-virtualbox-vhd|x-virtualbox-vmdk|x-www-form-urlencoded)|font\/(?:otf|ttf)|image\/(?:bmp|vnd\.adobe\.photoshop|vnd\.microsoft\.icon|vnd\.ms-dds|x-icon|x-ms-bmp)|message\/rfc822|model\/gltf-binary|x-shader\/x-fragment|x-shader\/x-vertex|[^;\s]+?\+(?:json|text|xml|yaml))(?:[;\s]|$)/i,it=(e,t=bs)=>{const s=/\.([a-zA-Z0-9]+?)$/,a=e.match(s);if(!a)return;let i=t[a[1].toLowerCase()];return i&&i.startsWith("text")&&(i+="; charset=utf-8"),i},gs={aac:"audio/aac",avi:"video/x-msvideo",avif:"image/avif",av1:"video/av1",bin:"application/octet-stream",bmp:"image/bmp",css:"text/css",csv:"text/csv",eot:"application/vnd.ms-fontobject",epub:"application/epub+zip",gif:"image/gif",gz:"application/gzip",htm:"text/html",html:"text/html",ico:"image/x-icon",ics:"text/calendar",jpeg:"image/jpeg",jpg:"image/jpeg",js:"text/javascript",json:"application/json",jsonld:"application/ld+json",map:"application/json",mid:"audio/x-midi",midi:"audio/x-midi",mjs:"text/javascript",mp3:"audio/mpeg",mp4:"video/mp4",mpeg:"video/mpeg",oga:"audio/ogg",ogv:"video/ogg",ogx:"application/ogg",opus:"audio/opus",otf:"font/otf",pdf:"application/pdf",png:"image/png",rtf:"application/rtf",svg:"image/svg+xml",tif:"image/tiff",tiff:"image/tiff",ts:"video/mp2t",ttf:"font/ttf",txt:"text/plain",wasm:"application/wasm",webm:"video/webm",weba:"audio/webm",webmanifest:"application/manifest+json",webp:"image/webp",woff:"font/woff",woff2:"font/woff2",xhtml:"application/xhtml+xml",xml:"application/xml",zip:"application/zip","3gp":"video/3gpp","3g2":"video/3gpp2",gltf:"model/gltf+json",glb:"model/gltf-binary"},bs=gs,ys=(...e)=>{let t=e.filter(i=>i!=="").join("/");t=t.replace(new RegExp("(?<=\\/)\\/+","g"),"");const s=t.split("/"),a=[];for(const i of s)i===".."&&a.length>0&&a.at(-1)!==".."?a.pop():i!=="."&&a.push(i);return a.join("/")||"."},Rt={br:".br",zstd:".zst",gzip:".gz"},ws=Object.keys(Rt),ks="index.html",$s=e=>{const t=e.root??"./",s=e.path,a=e.join??ys;return async(i,r)=>{var u,p,f,m;if(i.finalized)return r();let n;if(e.path)n=e.path;else try{if(n=ht(i.req.path),/(?:^|[\/\\])\.{1,2}(?:$|[\/\\])|[\/\\]{2,}/.test(n))throw new Error}catch{return await((u=e.onNotFound)==null?void 0:u.call(e,i.req.path,i)),r()}let l=a(t,!s&&e.rewriteRequestPath?e.rewriteRequestPath(n):n);e.isDir&&await e.isDir(l)&&(l=a(l,ks));const c=e.getContent;let d=await c(l,i);if(d instanceof Response)return i.newResponse(d.body,d);if(d){const g=e.mimes&&it(l,e.mimes)||it(l);if(i.header("Content-Type",g||"application/octet-stream"),e.precompressed&&(!g||ms.test(g))){const k=new Set((p=i.req.header("Accept-Encoding"))==null?void 0:p.split(",").map($=>$.trim()));for(const $ of ws){if(!k.has($))continue;const P=await c(l+Rt[$],i);if(P){d=P,i.header("Content-Encoding",$),i.header("Vary","Accept-Encoding",{append:!0});break}}}return await((f=e.onFound)==null?void 0:f.call(e,l,i)),i.body(d)}await((m=e.onNotFound)==null?void 0:m.call(e,l,i)),await r()}},js=async(e,t)=>{let s;t&&t.manifest?typeof t.manifest=="string"?s=JSON.parse(t.manifest):s=t.manifest:typeof __STATIC_CONTENT_MANIFEST=="string"?s=JSON.parse(__STATIC_CONTENT_MANIFEST):s=__STATIC_CONTENT_MANIFEST;let a;t&&t.namespace?a=t.namespace:a=__STATIC_CONTENT;const i=s[e];if(!i)return null;const r=await a.get(i,{type:"stream"});return r||null},As=e=>async function(s,a){return $s({...e,getContent:async r=>js(r,{manifest:e.manifest,namespace:e.namespace?e.namespace:s.env?s.env.__STATIC_CONTENT:void 0})})(s,a)},Cs=e=>As(e),Es=e=>{const s={...{origin:"*",allowMethods:["GET","HEAD","PUT","POST","DELETE","PATCH"],allowHeaders:[],exposeHeaders:[]},...e},a=(r=>typeof r=="string"?r==="*"?s.credentials?n=>n||null:()=>r:n=>r===n?n:null:typeof r=="function"?r:n=>r.includes(n)?n:null)(s.origin),i=(r=>typeof r=="function"?r:Array.isArray(r)?()=>r:()=>[])(s.allowMethods);return async function(n,l){var u;function c(p,f){n.res.headers.set(p,f)}const d=await a(n.req.header("origin")||"",n);if(d&&c("Access-Control-Allow-Origin",d),s.credentials&&c("Access-Control-Allow-Credentials","true"),(u=s.exposeHeaders)!=null&&u.length&&c("Access-Control-Expose-Headers",s.exposeHeaders.join(",")),n.req.method==="OPTIONS"){(s.origin!=="*"||s.credentials)&&c("Vary","Origin"),s.maxAge!=null&&c("Access-Control-Max-Age",s.maxAge.toString());const p=await i(n.req.header("origin")||"",n);p.length&&c("Access-Control-Allow-Methods",p.join(","));let f=s.allowHeaders;if(!(f!=null&&f.length)){const m=n.req.header("Access-Control-Request-Headers");m&&(f=m.split(/\s*,\s*/))}return f!=null&&f.length&&(c("Access-Control-Allow-Headers",f.join(",")),n.res.headers.append("Vary","Access-Control-Request-Headers")),n.res.headers.delete("Content-Length"),n.res.headers.delete("Content-Type"),new Response(null,{headers:n.res.headers,status:204,statusText:"No Content"})}await l(),(s.origin!=="*"||s.credentials)&&n.header("Vary","Origin",{append:!0})}},Tt=/^[\w!#$%&'*.^`|~+-]+$/,Ps=/^[ !#-:<-[\]-~]*$/,rt=e=>{let t=0,s=e.length;for(;t<s;){const a=e.charCodeAt(t);if(a!==32&&a!==9)break;t++}for(;s>t;){const a=e.charCodeAt(s-1);if(a!==32&&a!==9)break;s--}return t===0&&s===e.length?e:e.slice(t,s)},nt=(e,t)=>{if(t&&e.indexOf(t)===-1)return{};const s=e.split(";"),a={};for(const i of s){const r=i.indexOf("=");if(r===-1)continue;const n=rt(i.substring(0,r));if(t&&t!==n||!Tt.test(n))continue;let l=rt(i.substring(r+1));if(l.startsWith('"')&&l.endsWith('"')&&(l=l.slice(1,-1)),Ps.test(l)&&(a[n]=l.indexOf("%")!==-1?qe(l,Ye):l,t))break}return a},Ss=(e,t,s={})=>{if(!Tt.test(e))throw new Error("Invalid cookie name");let a=`${e}=${t}`;if(e.startsWith("__Secure-")&&!s.secure)throw new Error("__Secure- Cookie must have Secure attributes");if(e.startsWith("__Host-")){if(!s.secure)throw new Error("__Host- Cookie must have Secure attributes");if(s.path!=="/")throw new Error('__Host- Cookie must have Path attributes with "/"');if(s.domain)throw new Error("__Host- Cookie must not have Domain attributes")}for(const i of["domain","path"])if(s[i]&&/[;\r\n]/.test(s[i]))throw new Error(`${i} must not contain ";", "\\r", or "\\n"`);if(s&&typeof s.maxAge=="number"&&s.maxAge>=0){if(s.maxAge>3456e4)throw new Error("Cookies Max-Age SHOULD NOT be greater than 400 days (34560000 seconds) in duration.");a+=`; Max-Age=${s.maxAge|0}`}if(s.domain&&s.prefix!=="host"&&(a+=`; Domain=${s.domain}`),s.path&&(a+=`; Path=${s.path}`),s.expires){if(s.expires.getTime()-Date.now()>3456e7)throw new Error("Cookies Expires SHOULD NOT be greater than 400 days (34560000 seconds) in the future.");a+=`; Expires=${s.expires.toUTCString()}`}if(s.httpOnly&&(a+="; HttpOnly"),s.secure&&(a+="; Secure"),s.sameSite&&(a+=`; SameSite=${s.sameSite.charAt(0).toUpperCase()+s.sameSite.slice(1)}`),s.priority&&(a+=`; Priority=${s.priority.charAt(0).toUpperCase()+s.priority.slice(1)}`),s.partitioned){if(!s.secure)throw new Error("Partitioned Cookie must have Secure attributes");a+="; Partitioned"}return a},We=(e,t,s)=>(t=encodeURIComponent(t),Ss(e,t,s)),O=(e,t,s)=>{const a=e.req.raw.headers.get("Cookie");if(typeof t=="string"){if(!a)return;let r=t;return s==="secure"?r="__Secure-"+t:s==="host"&&(r="__Host-"+t),nt(a,r)[r]}return a?nt(a):{}},Rs=(e,t,s)=>{let a;return(s==null?void 0:s.prefix)==="secure"?a=We("__Secure-"+e,t,{path:"/",...s,secure:!0}):(s==null?void 0:s.prefix)==="host"?a=We("__Host-"+e,t,{...s,path:"/",secure:!0,domain:void 0}):a=We(e,t,{path:"/",...s}),a},E=(e,t,s,a)=>{const i=Rs(t,s,a);e.header("Set-Cookie",i,{append:!0})},G=(e,t,s)=>{const a=O(e,t,s==null?void 0:s.prefix);return E(e,t,"",{...s,maxAge:0}),a};const y=new St;y.use("/static/*",Cs({root:"./"}));y.use("/api/*",Es());async function Ts(e,t,s,a,i,r){return await fetch(`${e}/auth/v1/signup`,{method:"POST",headers:{"Content-Type":"application/json",apikey:s,Authorization:`Bearer ${s}`},body:JSON.stringify({email:a,password:i,data:r})})}async function _t(e,t,s,a){return await fetch(`${e}/auth/v1/token?grant_type=password`,{method:"POST",headers:{"Content-Type":"application/json",apikey:t,Authorization:`Bearer ${t}`},body:JSON.stringify({email:s,password:a})})}async function _s(e,t,s){return await fetch(`${e}/auth/v1/user`,{headers:{apikey:t,Authorization:`Bearer ${s}`}})}async function Ms(e,t,s){return await fetch(`${e}/rest/v1/profiles`,{method:"POST",headers:{"Content-Type":"application/json",apikey:t,Authorization:`Bearer ${t}`,Prefer:"return=minimal"},body:JSON.stringify(s)})}async function Os(e,t,s){return await fetch(`${e}/rest/v1/profiles?id=eq.${s}&select=*`,{headers:{apikey:t,Authorization:`Bearer ${t}`}})}async function _(e,t){var r,n;const s=O(e,"sb_token");if(!s)return e.redirect("/login?msg=session_expired");const a=((r=e.env)==null?void 0:r.SUPABASE_URL)||"",i=((n=e.env)==null?void 0:n.SUPABASE_ANON_KEY)||"";if(a&&!(await _s(a,i,s)).ok)return G(e,"sb_token"),e.redirect("/login?msg=session_expired");await t()}y.post("/api/auth/register",async e=>{var t;try{const s=await e.req.json(),{email:a,password:i,full_name:r,phone:n,role:l,country:c,whatsapp_number:d,is_diaspora:u}=s;if(!a||!i||!r||!n)return e.json({error:"Champs obligatoires manquants"},400);if(i.length<8)return e.json({error:"Le mot de passe doit contenir au moins 8 caractères"},400);const p=e.env.SUPABASE_URL,f=e.env.SUPABASE_ANON_KEY,m=e.env.SUPABASE_SERVICE_ROLE_KEY;if(!p||p==="YOUR_SUPABASE_URL"){const R=btoa(JSON.stringify({id:crypto.randomUUID(),email:a,full_name:r,role:l||"owner"}));return E(e,"sb_token",R,{httpOnly:!0,path:"/",maxAge:86400*7,sameSite:"Lax"}),E(e,"user_name",r,{path:"/",maxAge:86400*7}),E(e,"user_email",a,{path:"/",maxAge:86400*7}),E(e,"user_role",l||"owner",{path:"/",maxAge:86400*7}),e.json({success:!0,message:"Compte créé (mode démo)",redirect:"/dashboard"})}const g=await Ts(p,f,m,a,i,{full_name:r,phone:n,role:l||"owner"}),k=await g.json();if(!g.ok||k.error){const R=k.msg||k.error_description||k.error||"Erreur lors de la création du compte";return R.toLowerCase().includes("already registered")||R.toLowerCase().includes("already been registered")?e.json({error:"Cet email est déjà utilisé. Veuillez vous connecter."},409):e.json({error:R},400)}const $=((t=k.user)==null?void 0:t.id)||k.id;if(!$)return e.json({error:"Erreur serveur: ID utilisateur manquant"},500);await Ms(p,m,{id:$,full_name:r,phone:n,role:l||"owner",country:c||"BF",whatsapp_number:d||n,is_diaspora:u||!1});const P=await _t(p,f,a,i),w=await P.json();return P.ok&&w.access_token&&(E(e,"sb_token",w.access_token,{httpOnly:!0,path:"/",maxAge:86400*7,sameSite:"Lax"}),E(e,"user_name",r,{path:"/",maxAge:86400*7}),E(e,"user_email",a,{path:"/",maxAge:86400*7}),E(e,"user_role",l||"owner",{path:"/",maxAge:86400*7})),e.json({success:!0,message:"Compte créé avec succès !",redirect:"/dashboard"})}catch(s){return e.json({error:"Erreur serveur: "+(s.message||"inconnue")},500)}});y.post("/api/auth/login",async e=>{var t;try{const s=await e.req.json(),{email:a,password:i}=s;if(!a||!i)return e.json({error:"Email et mot de passe requis"},400);const r=e.env.SUPABASE_URL,n=e.env.SUPABASE_ANON_KEY,l=e.env.SUPABASE_SERVICE_ROLE_KEY;if(!r||r==="YOUR_SUPABASE_URL"){if(i.length<3)return e.json({error:"Identifiants incorrects"},401);const m=a.split("@")[0].replace(/[._]/g," ").replace(/\b\w/g,k=>k.toUpperCase()),g=btoa(JSON.stringify({id:crypto.randomUUID(),email:a,full_name:m,role:"owner"}));return E(e,"sb_token",g,{httpOnly:!0,path:"/",maxAge:86400*7,sameSite:"Lax"}),E(e,"user_name",m,{path:"/",maxAge:86400*7}),E(e,"user_email",a,{path:"/",maxAge:86400*7}),E(e,"user_role","owner",{path:"/",maxAge:86400*7}),e.json({success:!0,redirect:"/dashboard"})}const c=await _t(r,n,a,i),d=await c.json();if(!c.ok||d.error){const m=d.error_description||d.error||d.msg||"Identifiants incorrects";return m.toLowerCase().includes("invalid")||m.toLowerCase().includes("not found")?e.json({error:"Email ou mot de passe incorrect"},401):e.json({error:m},401)}const u=d.access_token;if(!u)return e.json({error:"Erreur d'authentification"},500);let p=a.split("@")[0],f="owner";if((t=d.user)!=null&&t.id){const m=await Os(r,l,d.user.id);if(m.ok){const g=await m.json();g!=null&&g[0]&&(p=g[0].full_name||p,f=g[0].role||"owner")}}return E(e,"sb_token",u,{httpOnly:!0,path:"/",maxAge:86400*7,sameSite:"Lax"}),E(e,"user_name",p,{path:"/",maxAge:86400*7}),E(e,"user_email",a,{path:"/",maxAge:86400*7}),E(e,"user_role",f,{path:"/",maxAge:86400*7}),e.json({success:!0,redirect:"/dashboard"})}catch(s){return e.json({error:"Erreur serveur: "+(s.message||"inconnue")},500)}});y.post("/api/auth/logout",async e=>(G(e,"sb_token",{path:"/"}),G(e,"user_name",{path:"/"}),G(e,"user_email",{path:"/"}),G(e,"user_role",{path:"/"}),e.json({success:!0,redirect:"/login"})));y.get("/api/auth/me",async e=>{const t=O(e,"sb_token"),s=O(e,"user_name"),a=O(e,"user_email"),i=O(e,"user_role");return t?e.json({authenticated:!0,name:s,email:a,role:i}):e.json({authenticated:!1},401)});y.get("/api/stats",_,e=>e.json({totalChantiers:12,chantiersActifs:7,budgetTotal:145e6,budgetConsomme:892e5,alertesEnAttente:3,livraisons:48,risqueScore:24}));y.get("/api/chantiers",_,e=>e.json([{id:1,name:"Villa Familiale — Zone 1",location:"Ouagadougou",progress:68,budget:45e6,spent:306e5,risk:15,status:"active"},{id:2,name:"Maison R+1 — Pissy",location:"Ouagadougou",progress:35,budget:28e6,spent:98e5,risk:42,status:"active"},{id:3,name:"Villa Bobo-Dioulasso",location:"Bobo-Dioulasso",progress:20,budget:54e6,spent:108e5,risk:71,status:"active"}]));y.get("/",e=>e.redirect("/login"));y.get("/login",e=>{if(O(e,"sb_token"))return e.redirect("/dashboard");const s=e.req.query("msg")||"",a=e.req.query("error")||"";return e.html(Fs(s,a))});y.get("/register",e=>O(e,"sb_token")?e.redirect("/dashboard"):e.html(Is()));y.get("/logout",async e=>(G(e,"sb_token",{path:"/"}),G(e,"user_name",{path:"/"}),G(e,"user_email",{path:"/"}),G(e,"user_role",{path:"/"}),e.redirect("/login?msg=logged_out")));y.get("/dashboard",_,e=>{const t=O(e,"user_name")||"Utilisateur",s=O(e,"user_role")||"owner";return e.html(Ds(t,s))});y.get("/chantiers",_,e=>e.html(Ls()));y.get("/chantier/:id",_,e=>e.html(Ns(e.req.param("id"))));y.get("/budget",_,e=>e.html(Bs()));y.get("/approvisionnements",_,e=>e.html(Us()));y.get("/materiaux",_,e=>e.html(qs()));y.get("/journal",_,e=>e.html(Hs()));y.get("/alertes",_,e=>e.html(zs()));y.get("/rapports",_,e=>e.html(Vs()));y.get("/abonnements",_,e=>e.html(Gs()));y.get("/admin",_,e=>e.html(Ks()));y.get("/profil",_,e=>{const t=O(e,"user_name")||"",s=O(e,"user_email")||"",a=O(e,"user_role")||"";return e.html(Ws(t,s,a))});function M(e,t){return`<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>${e} — FasoChantier</title>
<script src="https://cdn.tailwindcss.com"><\/script>
<script>
  tailwind.config = {
    theme: {
      extend: {
        colors: {
          brand: { 400:'#fb923c', 500:'#f97316', 600:'#ea580c', 700:'#c2410c' },
          dark:  { 900:'#0f1117', 800:'#13161f', 700:'#1a1f2e', 600:'#1e2538', 500:'#252d3d' }
        },
        fontFamily: { sans: ['Inter','system-ui','sans-serif'] }
      }
    }
  }
<\/script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet"/>
<link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.0/css/all.min.css" rel="stylesheet"/>
<style>
*{box-sizing:border-box}
:root{--sw:260px}
body{font-family:'Inter',sans-serif;background:#0f1117;color:#e2e8f0;overflow-x:hidden}
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:#1a1f2e}
::-webkit-scrollbar-thumb{background:#f97316;border-radius:3px}
.sidebar{width:var(--sw);background:linear-gradient(180deg,#13161f,#0f1117);border-right:1px solid rgba(249,115,22,.1);position:fixed;top:0;left:0;bottom:0;overflow-y:auto;z-index:50;transition:transform .3s}
.main-content{margin-left:var(--sw);min-height:100vh}
.nav-item{display:flex;align-items:center;gap:12px;padding:9px 14px;border-radius:10px;color:#94a3b8;text-decoration:none;font-size:14px;font-weight:500;transition:all .2s;margin-bottom:2px}
.nav-item:hover,.nav-item.active{background:rgba(249,115,22,.12);color:#fb923c}
.nav-item.active{border:1px solid rgba(249,115,22,.2)}
.nav-icon{width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:8px;font-size:13px;flex-shrink:0}
.nav-item.active .nav-icon{background:rgba(249,115,22,.2);color:#f97316}
.topbar{background:rgba(15,17,23,.95);border-bottom:1px solid rgba(255,255,255,.06);backdrop-filter:blur(20px);position:sticky;top:0;z-index:40}
.card{background:linear-gradient(145deg,#1a1f2e,#161b27);border:1px solid rgba(255,255,255,.06);border-radius:16px;transition:all .25s}
.card:hover{border-color:rgba(249,115,22,.18);transform:translateY(-1px);box-shadow:0 8px 32px rgba(0,0,0,.3)}
.btn-primary{background:linear-gradient(135deg,#ea580c,#f97316);color:#fff;border:none;padding:10px 22px;border-radius:10px;font-weight:600;font-size:14px;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:8px;text-decoration:none}
.btn-primary:hover{background:linear-gradient(135deg,#c2410c,#ea580c);transform:translateY(-1px);box-shadow:0 4px 16px rgba(249,115,22,.35)}
.btn-secondary{background:rgba(255,255,255,.07);color:#e2e8f0;border:1px solid rgba(255,255,255,.1);padding:10px 22px;border-radius:10px;font-weight:500;font-size:14px;cursor:pointer;transition:all .2s;display:inline-flex;align-items:center;gap:8px;text-decoration:none}
.btn-secondary:hover{background:rgba(255,255,255,.12)}
.badge{display:inline-flex;align-items:center;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600}
.badge-success{background:rgba(34,197,94,.15);color:#22c55e}
.badge-warning{background:rgba(234,179,8,.15);color:#eab308}
.badge-danger{background:rgba(239,68,68,.15);color:#ef4444}
.badge-info{background:rgba(59,130,246,.15);color:#3b82f6}
.badge-orange{background:rgba(249,115,22,.15);color:#f97316}
.progress-bar{background:rgba(255,255,255,.07);border-radius:99px;overflow:hidden}
.progress-fill{height:100%;border-radius:99px;transition:width .8s}
.input{background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:10px;color:#e2e8f0;padding:10px 14px;font-size:14px;width:100%;transition:all .2s;outline:none;font-family:inherit}
.input:focus{border-color:#f97316;background:rgba(249,115,22,.05);box-shadow:0 0 0 3px rgba(249,115,22,.1)}
.input::placeholder{color:#4b5563}
.table-row{border-bottom:1px solid rgba(255,255,255,.04);transition:background .15s}
.table-row:hover{background:rgba(249,115,22,.04)}
.grad-text{background:linear-gradient(135deg,#f97316,#fb923c);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.glass{background:rgba(26,31,46,.8);backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.07)}
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.animate-fade-in{animation:fadeIn .4s ease-out}
@keyframes slideIn{from{transform:translateX(-16px);opacity:0}to{transform:translateX(0);opacity:1}}
.animate-slide{animation:slideIn .3s ease-out}
@media(max-width:768px){.sidebar{transform:translateX(-100%)}.sidebar.open{transform:translateX(0)}.main-content{margin-left:0}}
.spinner{width:18px;height:18px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .7s linear infinite;display:inline-block}
@keyframes spin{to{transform:rotate(360deg)}}
.error-box{background:rgba(239,68,68,.12);border:1px solid rgba(239,68,68,.3);color:#fca5a5;padding:12px 16px;border-radius:10px;font-size:13px;display:flex;align-items:center;gap:8px}
.success-box{background:rgba(34,197,94,.12);border:1px solid rgba(34,197,94,.3);color:#86efac;padding:12px 16px;border-radius:10px;font-size:13px;display:flex;align-items:center;gap:8px}
</style>
</head>
<body>${t}
<script>
function toggleSidebar(){document.getElementById('sidebar')?.classList.toggle('open')}
function closeModal(id){document.getElementById(id)?.classList.add('hidden')}
function openModal(id){document.getElementById(id)?.classList.remove('hidden')}
function showToast(msg,type='success'){
  const t=document.createElement('div');
  const c={success:'#22c55e',error:'#ef4444',warning:'#eab308',info:'#3b82f6'}[type]||'#22c55e';
  t.style.cssText='position:fixed;bottom:24px;right:24px;z-index:9999;background:'+c+';color:#fff;padding:12px 20px;border-radius:12px;font-size:14px;font-weight:500;display:flex;align-items:center;gap:10px;box-shadow:0 8px 32px rgba(0,0,0,.3);animation:fadeIn .3s ease-out';
  t.innerHTML='<i class="fas fa-check-circle"></i>'+msg;
  document.body.appendChild(t);
  setTimeout(()=>t.remove(),3500);
}
// Counter animation
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('[data-count]').forEach(el=>{
    const target=parseInt(el.dataset.count);let c=0;
    const step=target/50;
    const timer=setInterval(()=>{c+=step;if(c>=target){c=target;clearInterval(timer);}el.textContent=Math.floor(c).toLocaleString('fr-FR');},25);
  });
});
// API helper
async function apiPost(url, data){
  const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  return res.json();
}
function setLoading(btn,loading){
  if(loading){btn.dataset.orig=btn.innerHTML;btn.innerHTML='<span class="spinner"></span> Chargement...';btn.disabled=true;}
  else{btn.innerHTML=btn.dataset.orig||btn.innerHTML;btn.disabled=false;}
}
function showError(id,msg){
  const el=document.getElementById(id);
  if(el){el.innerHTML='<i class="fas fa-exclamation-circle"></i>'+msg;el.className='error-box mt-3';el.style.display='flex';}
}
function showSuccess(id,msg){
  const el=document.getElementById(id);
  if(el){el.innerHTML='<i class="fas fa-check-circle"></i>'+msg;el.className='success-box mt-3';el.style.display='flex';}
}
<\/script>
</body></html>`}function I(e){const t=[["/dashboard","fa-grid-2","Tableau de bord",""],["/chantiers","fa-hard-hat","Mes Chantiers",""],["/budget","fa-chart-pie","Budget & Finances",""],["/approvisionnements","fa-truck","Approvisionnements",""],["/materiaux","fa-boxes-stacked","Matériaux & Stock",""],["/journal","fa-book-open","Journal de Chantier",""],["/alertes","fa-bell","Alertes & IA","3"],["/rapports","fa-file-chart-column","Rapports",""]],s=[["/abonnements","fa-crown","Abonnements","PRO"],["/profil","fa-user-circle","Mon Profil",""],["/admin","fa-shield-halved","Administration",""]];return`<aside class="sidebar" id="sidebar">
  <div class="p-5 border-b border-white/5">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:linear-gradient(135deg,#ea580c,#f97316)">
        <i class="fas fa-hard-hat text-white text-lg"></i>
      </div>
      <div>
        <div class="grad-text font-black text-lg leading-none">FasoChantier</div>
        <div class="text-xs text-slate-500 mt-0.5">v2.0 · Production</div>
      </div>
    </div>
  </div>
  <div class="mx-3 mt-3 mb-1 p-3 rounded-xl bg-white/[0.04] border border-white/[0.05] flex items-center gap-3" id="sidebar-user">
    <div class="w-9 h-9 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-white font-bold text-sm flex-shrink-0" id="sidebar-avatar">?</div>
    <div class="overflow-hidden">
      <div class="text-sm font-600 text-white truncate" id="sidebar-name">Chargement...</div>
      <div class="text-xs text-slate-500" id="sidebar-role">—</div>
    </div>
    <div class="ml-auto w-2 h-2 rounded-full bg-green-400 flex-shrink-0"></div>
  </div>
  <nav class="px-2 py-2">
    <div class="text-xs font-600 text-slate-600 uppercase tracking-wider px-3 mb-1 mt-2">Navigation</div>
    ${t.map(([a,i,r,n])=>`
    <a href="${a}" class="nav-item ${e===a?"active":""}">
      <div class="nav-icon"><i class="fas ${i}"></i></div>
      <span>${r}</span>
      ${n?`<span class="ml-auto badge badge-danger text-xs">${n}</span>`:""}
    </a>`).join("")}
    <div class="text-xs font-600 text-slate-600 uppercase tracking-wider px-3 mb-1 mt-4">Compte</div>
    ${s.map(([a,i,r,n])=>`
    <a href="${a}" class="nav-item ${e===a?"active":""}">
      <div class="nav-icon"><i class="fas ${i}"></i></div>
      <span>${r}</span>
      ${n?`<span class="ml-auto badge badge-orange text-xs">${n}</span>`:""}
    </a>`).join("")}
  </nav>
  <div class="mx-3 my-3 p-3 rounded-xl border border-white/5 bg-white/[0.02]">
    <div class="flex justify-between text-xs mb-1.5">
      <span class="text-slate-400">Chantiers actifs</span>
      <span class="text-orange-400 font-700">7/10</span>
    </div>
    <div class="progress-bar h-1.5 mb-1.5"><div class="progress-fill bg-orange-500" style="width:70%"></div></div>
    <a href="/abonnements" class="text-xs text-orange-400 hover:underline">Passer Entreprise →</a>
  </div>
  <div class="px-3 pb-4 border-t border-white/5 pt-2">
    <button onclick="doLogout()" class="nav-item w-full text-red-400 hover:bg-red-500/10 hover:text-red-400">
      <div class="nav-icon text-red-400"><i class="fas fa-right-from-bracket"></i></div>
      <span>Déconnexion</span>
    </button>
  </div>
</aside>
<script>
// Load user info
fetch('/api/auth/me').then(r=>r.json()).then(d=>{
  if(d.authenticated){
    const initials=(d.name||'?').split(' ').map(n=>n[0]).join('').slice(0,2).toUpperCase();
    document.getElementById('sidebar-avatar').textContent=initials;
    document.getElementById('sidebar-name').textContent=d.name||d.email||'Utilisateur';
    const roles={owner:'Propriétaire',controller:'Contrôleur',worker:'Tâcheron',admin:'Administrateur'};
    document.getElementById('sidebar-role').textContent=(roles[d.role]||d.role)+' · Pro';
  }
});
async function doLogout(){
  await fetch('/api/auth/logout',{method:'POST'});
  window.location.href='/login?msg=logged_out';
}
<\/script>`}function D(e,t=""){return`<header class="topbar px-6 py-4 flex items-center justify-between">
  <div class="flex items-center gap-4">
    <button onclick="toggleSidebar()" class="md:hidden w-9 h-9 flex items-center justify-center rounded-lg hover:bg-white/10 text-slate-400">
      <i class="fas fa-bars"></i>
    </button>
    <div>
      <h1 class="text-lg font-700 text-white leading-tight">${e}</h1>
      ${t?`<p class="text-xs text-slate-500">${t}</p>`:""}
    </div>
  </div>
  <div class="flex items-center gap-3">
    <div class="hidden md:flex items-center gap-2 bg-white/[0.05] border border-white/[0.08] rounded-10 px-3 py-2">
      <i class="fas fa-search text-slate-500 text-sm"></i>
      <input placeholder="Rechercher..." class="bg-transparent text-sm text-white outline-none placeholder:text-slate-600 w-44"/>
    </div>
    <div class="relative">
      <button class="w-9 h-9 flex items-center justify-center rounded-lg bg-white/[0.05] hover:bg-white/10 text-slate-300">
        <i class="fas fa-bell text-sm"></i>
      </button>
      <span class="absolute top-1.5 right-1.5 w-2 h-2 bg-orange-500 rounded-full"></span>
    </div>
    <a href="/chantiers" class="btn-primary hidden md:inline-flex text-sm py-2 px-4">
      <i class="fas fa-plus text-xs"></i> Nouveau Chantier
    </a>
  </div>
</header>`}function Fs(e="",t=""){const s=e==="logged_out"?'<div class="success-box mb-4"><i class="fas fa-check-circle"></i>Vous avez été déconnecté avec succès.</div>':e==="session_expired"?'<div class="error-box mb-4"><i class="fas fa-exclamation-circle"></i>Votre session a expiré. Reconnectez-vous.</div>':"";return M("Connexion",`
<div class="min-h-screen flex" style="background:linear-gradient(135deg,#090b10 0%,#0f1117 60%,#13161f 100%)">
  <!-- Left decorative panel -->
  <div class="hidden lg:flex flex-col justify-between w-[460px] flex-shrink-0 p-10 relative overflow-hidden" style="background:linear-gradient(160deg,#13161f,#0f1117)">
    <div class="absolute inset-0 overflow-hidden pointer-events-none">
      <div class="absolute -top-24 -left-24 w-72 h-72 rounded-full opacity-15" style="background:radial-gradient(circle,#f97316,transparent)"></div>
      <div class="absolute -bottom-24 -right-24 w-96 h-96 rounded-full opacity-10" style="background:radial-gradient(circle,#ea580c,transparent)"></div>
    </div>
    <div class="relative z-10">
      <div class="flex items-center gap-3 mb-10">
        <div class="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg" style="background:linear-gradient(135deg,#ea580c,#f97316)">
          <i class="fas fa-hard-hat text-white text-xl"></i>
        </div>
        <div>
          <div class="font-black text-xl text-white">FasoChantier</div>
          <div class="text-xs text-slate-500">Contrôle Intelligent de Chantier</div>
        </div>
      </div>
      <h2 class="text-3xl font-800 text-white leading-tight mb-3">Gérez votre chantier<br/>depuis n'importe où</h2>
      <p class="text-slate-400 text-sm leading-relaxed mb-8">Suivi des matériaux, contrôle des dépenses et alertes instantanées. Même sans connexion internet.</p>
      <div class="space-y-4">
        ${[["fa-shield-check","#22c55e","Protection Anti-Vol","Validation photo de chaque livraison"],["fa-chart-line-up","#3b82f6","Suivi Budgétaire","Graphiques et alertes en temps réel"],["fa-robot","#a855f7","IA de Détection","Anomalies et fraudes automatiquement"],["fa-wifi-slash","#f97316","Offline-First","Synchronisation automatique"]].map(([a,i,r,n])=>`
        <div class="flex items-start gap-3">
          <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style="background:${i}20">
            <i class="fas ${a} text-sm" style="color:${i}"></i>
          </div>
          <div><div class="font-600 text-sm text-white">${r}</div><div class="text-xs text-slate-500">${n}</div></div>
        </div>`).join("")}
      </div>
    </div>
    <div class="relative z-10 glass rounded-2xl p-4">
      <div class="flex gap-1 mb-2">${'<i class="fas fa-star text-yellow-400 text-xs"></i>'.repeat(5)}</div>
      <p class="text-sm text-slate-300 italic">"FasoChantier m'a permis d'économiser 2 millions de FCFA en détectant des livraisons fantômes sur mon chantier."</p>
      <div class="flex items-center gap-2 mt-3">
        <div class="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-red-600 flex items-center justify-center text-white text-xs font-700">MB</div>
        <div><div class="text-xs font-600 text-white">Moussa Belemkieta</div><div class="text-xs text-slate-500">Entrepreneur — Ouagadougou</div></div>
      </div>
    </div>
  </div>

  <!-- Right form panel -->
  <div class="flex-1 flex items-center justify-center p-6">
    <div class="w-full max-w-[420px] animate-fade-in">
      <div class="lg:hidden flex items-center gap-3 mb-8 justify-center">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:linear-gradient(135deg,#ea580c,#f97316)">
          <i class="fas fa-hard-hat text-white"></i>
        </div>
        <div class="grad-text font-black text-xl">FasoChantier</div>
      </div>
      <div class="card p-8">
        <div class="mb-6">
          <h2 class="text-2xl font-800 text-white">Bon retour 👋</h2>
          <p class="text-slate-500 text-sm mt-1">Connectez-vous pour accéder à votre espace</p>
        </div>
        ${s}
        <div id="login-msg" class="hidden"></div>

        <form id="login-form" class="space-y-4" onsubmit="handleLogin(event)">
          <div>
            <label class="text-sm font-500 text-slate-400 mb-1.5 block">Adresse email</label>
            <input type="email" id="login-email" placeholder="votre@email.com" class="input" required autocomplete="email"/>
          </div>
          <div>
            <div class="flex items-center justify-between mb-1.5">
              <label class="text-sm font-500 text-slate-400">Mot de passe</label>
              <a href="#" class="text-xs text-orange-400 hover:underline">Mot de passe oublié ?</a>
            </div>
            <div class="relative">
              <input type="password" id="login-pwd" placeholder="••••••••" class="input pr-10" required autocomplete="current-password"/>
              <button type="button" onclick="togglePwd('login-pwd','eye1')" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
                <i class="fas fa-eye text-sm" id="eye1"></i>
              </button>
            </div>
          </div>
          <label class="flex items-center gap-2 cursor-pointer">
            <input type="checkbox" checked class="w-4 h-4 accent-orange-500 rounded"/>
            <span class="text-sm text-slate-400">Rester connecté</span>
          </label>
          <button type="submit" id="login-btn" class="btn-primary w-full justify-center py-3 text-base mt-1">
            <i class="fas fa-right-to-bracket"></i> Se connecter
          </button>
        </form>

        <div class="flex items-center gap-3 my-5">
          <div class="flex-1 h-px bg-white/10"></div>
          <span class="text-xs text-slate-600">ou</span>
          <div class="flex-1 h-px bg-white/10"></div>
        </div>
        <div class="grid grid-cols-2 gap-3">
          <button onclick="showToast('Google Auth bientôt disponible','info')" class="btn-secondary justify-center py-2.5 text-sm"><i class="fab fa-google text-red-400"></i> Google</button>
          <button onclick="showToast('WhatsApp Auth bientôt disponible','info')" class="btn-secondary justify-center py-2.5 text-sm"><i class="fab fa-whatsapp text-green-400"></i> WhatsApp</button>
        </div>
        <p class="text-center text-sm text-slate-500 mt-5">
          Pas encore inscrit ? <a href="/register" class="text-orange-400 font-600 hover:underline">Créer un compte</a>
        </p>
      </div>
      <div class="flex items-center justify-center gap-6 mt-5">
        <div class="flex items-center gap-1.5 text-xs text-slate-600"><i class="fas fa-lock text-green-400"></i> SSL Sécurisé</div>
        <div class="flex items-center gap-1.5 text-xs text-slate-600"><i class="fas fa-shield text-blue-400"></i> RGPD Conforme</div>
        <div class="flex items-center gap-1.5 text-xs text-slate-600"><i class="fas fa-wifi-slash text-orange-400"></i> Offline Ready</div>
      </div>
    </div>
  </div>
</div>
<script>
function togglePwd(id,eyeId){
  const f=document.getElementById(id);const e=document.getElementById(eyeId);
  if(f.type==='password'){f.type='text';e.classList.replace('fa-eye','fa-eye-slash');}
  else{f.type='password';e.classList.replace('fa-eye-slash','fa-eye');}
}
async function handleLogin(e){
  e.preventDefault();
  const btn=document.getElementById('login-btn');
  const email=document.getElementById('login-email').value.trim();
  const password=document.getElementById('login-pwd').value;
  setLoading(btn,true);
  document.getElementById('login-msg').style.display='none';
  try{
    const data=await apiPost('/api/auth/login',{email,password});
    if(data.success){
      showSuccess('login-msg','Connexion réussie ! Redirection...');
      setTimeout(()=>window.location.href=data.redirect||'/dashboard',800);
    } else {
      showError('login-msg',data.error||'Identifiants incorrects');
      setLoading(btn,false);
    }
  } catch(err){
    showError('login-msg','Erreur réseau. Vérifiez votre connexion.');
    setLoading(btn,false);
  }
}
<\/script>`)}function Is(){return M("Inscription",`
<div class="min-h-screen flex items-center justify-center p-6" style="background:linear-gradient(135deg,#090b10,#0f1117)">
  <div class="w-full max-w-[540px] animate-fade-in">
    <div class="text-center mb-8">
      <div class="inline-flex items-center gap-3 mb-4">
        <div class="w-12 h-12 rounded-2xl flex items-center justify-center" style="background:linear-gradient(135deg,#ea580c,#f97316)">
          <i class="fas fa-hard-hat text-white text-xl"></i>
        </div>
      </div>
      <h1 class="text-3xl font-800 text-white">Créer votre compte</h1>
      <p class="text-slate-500 text-sm mt-2">Commencez à contrôler votre chantier en 2 minutes</p>
    </div>
    <div class="card p-8">
      <!-- Plan selector -->
      <div class="mb-6">
        <label class="text-sm font-500 text-slate-400 mb-3 block">Choisissez votre formule</label>
        <div class="grid grid-cols-3 gap-2">
          ${[["basic","Basic","50k FCFA","fa-seedling","#94a3b8"],["pro","Pro","100k FCFA","fa-rocket","#f97316"],["enterprise","Entreprise","Sur devis","fa-building","#a855f7"]].map(([e,t,s,a,i],r)=>`
          <label class="cursor-pointer">
            <input type="radio" name="plan_sel" value="${e}" class="hidden peer" ${r===1?"checked":""}>
            <div class="peer-checked:border-orange-500 peer-checked:bg-orange-500/10 border border-white/10 rounded-xl p-3 text-center transition-all hover:border-white/20">
              <i class="fas ${a} mb-1 block text-lg" style="color:${i}"></i>
              <div class="text-xs font-700 text-white">${t}</div>
              <div class="text-xs text-slate-500">${s}</div>
            </div>
          </label>`).join("")}
        </div>
      </div>

      <div id="register-msg" class="hidden mb-3"></div>

      <form id="register-form" class="space-y-4" onsubmit="handleRegister(event)">
        <div class="grid grid-cols-2 gap-3">
          <div>
            <label class="text-xs font-500 text-slate-400 mb-1 block">Prénom *</label>
            <input type="text" id="reg-firstname" placeholder="Kofi" class="input" required/>
          </div>
          <div>
            <label class="text-xs font-500 text-slate-400 mb-1 block">Nom *</label>
            <input type="text" id="reg-lastname" placeholder="Sawadogo" class="input" required/>
          </div>
        </div>
        <div>
          <label class="text-xs font-500 text-slate-400 mb-1 block">Email *</label>
          <input type="email" id="reg-email" placeholder="kofi@example.com" class="input" required autocomplete="email"/>
        </div>
        <div>
          <label class="text-xs font-500 text-slate-400 mb-1 block">Téléphone / WhatsApp *</label>
          <div class="flex gap-2">
            <select id="reg-prefix" class="input w-28 flex-shrink-0">
              <option value="+226">🇧🇫 +226</option>
              <option value="+225">🇨🇮 +225</option>
              <option value="+221">🇸🇳 +221</option>
              <option value="+223">🇲🇱 +223</option>
              <option value="+33">🇫🇷 +33</option>
              <option value="+1">🇺🇸 +1</option>
            </select>
            <input type="tel" id="reg-phone" placeholder="70 00 00 00" class="input flex-1" required/>
          </div>
        </div>
        <div>
          <label class="text-xs font-500 text-slate-400 mb-1 block">Rôle</label>
          <select id="reg-role" class="input">
            <option value="owner">Propriétaire</option>
            <option value="controller">Contrôleur de chantier</option>
            <option value="worker">Tâcheron / Maçon</option>
          </select>
        </div>
        <div>
          <label class="text-xs font-500 text-slate-400 mb-1 block">Pays de résidence</label>
          <select id="reg-country" class="input">
            <option value="BF">🇧🇫 Burkina Faso</option>
            <option value="CI">🇨🇮 Côte d'Ivoire</option>
            <option value="SN">🇸🇳 Sénégal</option>
            <option value="ML">🇲🇱 Mali</option>
            <option value="FR">🇫🇷 France (Diaspora)</option>
            <option value="US">🇺🇸 USA (Diaspora)</option>
          </select>
        </div>
        <div>
          <label class="text-xs font-500 text-slate-400 mb-1 block">Mot de passe * (min. 8 caractères)</label>
          <div class="relative">
            <input type="password" id="reg-pwd" placeholder="Minimum 8 caractères" class="input pr-10" required autocomplete="new-password" minlength="8"/>
            <button type="button" onclick="togglePwd2()" class="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300">
              <i class="fas fa-eye text-sm" id="eye2"></i>
            </button>
          </div>
        </div>
        <label class="flex items-start gap-2 cursor-pointer">
          <input type="checkbox" id="reg-terms" class="w-4 h-4 accent-orange-500 rounded mt-0.5" required/>
          <span class="text-xs text-slate-400">J'accepte les <a href="#" class="text-orange-400 hover:underline">Conditions d'utilisation</a> et la <a href="#" class="text-orange-400 hover:underline">Politique de confidentialité</a></span>
        </label>
        <button type="submit" id="reg-btn" class="btn-primary w-full justify-center py-3 text-base">
          <i class="fas fa-user-plus"></i> Créer mon compte
        </button>
      </form>
      <p class="text-center text-sm text-slate-500 mt-5">
        Déjà inscrit ? <a href="/login" class="text-orange-400 font-600 hover:underline">Se connecter</a>
      </p>
    </div>
  </div>
</div>
<script>
function togglePwd2(){
  const f=document.getElementById('reg-pwd');const e=document.getElementById('eye2');
  if(f.type==='password'){f.type='text';e.classList.replace('fa-eye','fa-eye-slash');}
  else{f.type='password';e.classList.replace('fa-eye-slash','fa-eye');}
}
async function handleRegister(e){
  e.preventDefault();
  const btn=document.getElementById('reg-btn');
  const firstname=document.getElementById('reg-firstname').value.trim();
  const lastname=document.getElementById('reg-lastname').value.trim();
  const email=document.getElementById('reg-email').value.trim();
  const prefix=document.getElementById('reg-prefix').value;
  const phone=document.getElementById('reg-phone').value.trim();
  const role=document.getElementById('reg-role').value;
  const country=document.getElementById('reg-country').value;
  const password=document.getElementById('reg-pwd').value;
  const full_name=firstname+' '+lastname;
  const fullphone=prefix+phone;
  if(password.length<8){showError('register-msg','Le mot de passe doit avoir au moins 8 caractères');return;}
  setLoading(btn,true);
  document.getElementById('register-msg').style.display='none';
  try{
    const data=await apiPost('/api/auth/register',{
      email,password,full_name,phone:fullphone,
      role,country,whatsapp_number:fullphone,
      is_diaspora:country==='FR'||country==='US'
    });
    if(data.success){
      showSuccess('register-msg','Compte créé avec succès ! Redirection...');
      setTimeout(()=>window.location.href=data.redirect||'/dashboard',1000);
    } else {
      showError('register-msg',data.error||'Erreur lors de la création du compte');
      setLoading(btn,false);
    }
  } catch(err){
    showError('register-msg','Erreur réseau. Vérifiez votre connexion.');
    setLoading(btn,false);
  }
}
<\/script>`)}function Ds(e="Utilisateur",t="owner"){const s={owner:"Propriétaire",controller:"Contrôleur",worker:"Tâcheron",admin:"Administrateur"};return M("Tableau de bord",`
<div class="flex">
  ${I("/dashboard")}
  <div class="main-content flex-1">
    ${D("Tableau de bord",`Bonjour ${e} 👋 — ${s[t]||t}`)}
    <main class="p-6 space-y-6 animate-fade-in">
      <!-- KPIs -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
        ${[{label:"Budget Total",val:"145 000 000",unit:"FCFA",icon:"fa-wallet",color:"#f97316",border:"border-l-orange-500",cnt:"145000000",delta:"Tous chantiers"},{label:"Dépenses",val:"89 200 000",unit:"FCFA",icon:"fa-money-bill-trend-up",color:"#ef4444",border:"border-l-red-500",cnt:"89200000",delta:"61.5% du budget"},{label:"Chantiers Actifs",val:"7",unit:"/ 12 total",icon:"fa-hard-hat",color:"#22c55e",border:"border-l-green-500",cnt:"7",delta:"+1 cette semaine"},{label:"Alertes",val:"3",unit:"à traiter",icon:"fa-triangle-exclamation",color:"#eab308",border:"border-l-yellow-500",cnt:"3",delta:"1 critique"}].map(a=>`
        <div class="card border-l-2 ${a.border} p-5">
          <div class="flex items-start justify-between mb-3">
            <div>
              <div class="text-xs font-500 text-slate-500 mb-1">${a.label}</div>
              <div class="text-2xl font-800 text-white leading-none" data-count="${a.cnt}">${a.val}</div>
              <div class="text-xs text-slate-500 mt-0.5">${a.unit}</div>
            </div>
            <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:${a.color}20">
              <i class="fas ${a.icon}" style="color:${a.color}"></i>
            </div>
          </div>
          <div class="text-xs text-slate-500">${a.delta}</div>
        </div>`).join("")}
      </div>

      <div class="grid lg:grid-cols-3 gap-6">
        <!-- Chart dépenses -->
        <div class="card p-6 lg:col-span-2">
          <div class="flex items-center justify-between mb-5">
            <div><h3 class="font-700 text-white">Évolution des Dépenses</h3><p class="text-xs text-slate-500">6 derniers mois — en millions FCFA</p></div>
            <span class="badge badge-orange text-xs">Temps réel</span>
          </div>
          <div class="flex items-end gap-3 h-36 mb-3">
            ${[["Jan",65],["Fév",48],["Mar",80],["Avr",55],["Mai",92],["Jui",70]].map(([a,i])=>`
            <div class="flex-1 flex flex-col items-center gap-2">
              <div class="text-xs text-slate-500 font-600">${Math.round(Number(i)*1.45)}M</div>
              <div class="w-full rounded-t-md" style="height:${i}%;background:linear-gradient(180deg,#f97316,#ea580c88)"></div>
              <div class="text-xs text-slate-600">${a}</div>
            </div>`).join("")}
          </div>
          <div class="flex items-center gap-4 text-xs text-slate-500 border-t border-white/5 pt-3">
            <div class="flex items-center gap-1.5"><div class="w-2.5 h-2.5 rounded-full bg-orange-500"></div>Dépenses réelles</div>
          </div>
        </div>
        <!-- Risk score -->
        <div class="space-y-4">
          <div class="card p-5">
            <div class="flex items-center justify-between mb-4">
              <h3 class="font-700 text-white text-sm">Score Risque IA</h3>
              <span class="badge badge-warning">MODÉRÉ</span>
            </div>
            <div class="relative flex items-center justify-center mb-4">
              <svg viewBox="0 0 120 120" class="w-28 h-28">
                <circle cx="60" cy="60" r="50" fill="none" stroke="rgba(255,255,255,.06)" stroke-width="10"/>
                <circle cx="60" cy="60" r="50" fill="none" stroke="#eab308" stroke-width="10"
                  stroke-dasharray="75.4 239" stroke-linecap="round" transform="rotate(-90 60 60)"/>
              </svg>
              <div class="absolute text-center">
                <div class="text-3xl font-900 text-yellow-400">24</div>
                <div class="text-xs text-slate-500">/100</div>
              </div>
            </div>
            <div class="space-y-2 text-xs">
              ${[["Anomalies prix","2","#ef4444"],["Retards","1","#eab308"],["Livraisons ok","45","#22c55e"]].map(([a,i,r])=>`
              <div class="flex items-center justify-between">
                <span class="text-slate-400">${a}</span>
                <span class="font-700" style="color:${r}">${i}</span>
              </div>`).join("")}
            </div>
          </div>
          <div class="card p-5">
            <h3 class="font-700 text-white text-sm mb-3">Répartition Budget</h3>
            <div class="space-y-2.5">
              ${[["Matériaux",55,"#f97316"],["Main d'œuvre",30,"#3b82f6"],["Transport",10,"#a855f7"],["Divers",5,"#22c55e"]].map(([a,i,r])=>`
              <div>
                <div class="flex justify-between text-xs mb-1"><span class="text-slate-400">${a}</span><span style="color:${r}" class="font-600">${i}%</span></div>
                <div class="progress-bar h-1.5"><div class="progress-fill" style="width:${i}%;background:${r}"></div></div>
              </div>`).join("")}
            </div>
          </div>
        </div>
      </div>

      <!-- Chantiers table -->
      <div class="card p-6">
        <div class="flex items-center justify-between mb-5">
          <h3 class="font-700 text-white">Chantiers en cours</h3>
          <a href="/chantiers" class="btn-secondary text-sm py-2 px-4">Voir tous <i class="fas fa-arrow-right text-xs ml-1"></i></a>
        </div>
        <div class="overflow-x-auto">
          <table class="w-full">
            <thead><tr class="border-b border-white/5">
              <th class="text-left py-2 px-3 text-xs font-600 text-slate-500">CHANTIER</th>
              <th class="text-left py-2 px-3 text-xs font-600 text-slate-500">AVANCEMENT</th>
              <th class="text-left py-2 px-3 text-xs font-600 text-slate-500">BUDGET</th>
              <th class="text-left py-2 px-3 text-xs font-600 text-slate-500">RISQUE</th>
              <th class="text-left py-2 px-3 text-xs font-600 text-slate-500">STATUT</th>
              <th class="py-2 px-3"></th>
            </tr></thead>
            <tbody>
              ${[{name:"Villa Familiale — Zone 1",loc:"Ouagadougou",prog:68,budget:"45M",spent:"30.6M",risk:15,rc:"text-green-400"},{name:"Maison R+1 — Pissy",loc:"Ouagadougou",prog:35,budget:"28M",spent:"9.8M",risk:42,rc:"text-yellow-400"},{name:"Commerce Gounghin",loc:"Ouagadougou",prog:82,budget:"18M",spent:"14.7M",risk:8,rc:"text-green-400"},{name:"Villa Bobo-Dioulasso",loc:"Bobo-Dioulasso",prog:20,budget:"54M",spent:"10.8M",risk:71,rc:"text-red-400"}].map(a=>`
              <tr class="table-row">
                <td class="py-3 px-3">
                  <div class="font-600 text-sm text-white">${a.name}</div>
                  <div class="text-xs text-slate-500"><i class="fas fa-location-dot text-orange-500 mr-1"></i>${a.loc}</div>
                </td>
                <td class="py-3 px-3">
                  <div class="flex items-center gap-2">
                    <div class="progress-bar h-1.5 w-20"><div class="progress-fill bg-orange-500" style="width:${a.prog}%"></div></div>
                    <span class="text-xs font-600 text-white">${a.prog}%</span>
                  </div>
                </td>
                <td class="py-3 px-3">
                  <div class="text-xs text-white font-600">${a.spent} FCFA</div>
                  <div class="text-xs text-slate-500">/ ${a.budget}</div>
                </td>
                <td class="py-3 px-3 text-sm font-700 ${a.rc}">${a.risk}/100</td>
                <td class="py-3 px-3"><span class="badge badge-success">Actif</span></td>
                <td class="py-3 px-3"><a href="/chantier/1" class="text-orange-400 hover:text-orange-300"><i class="fas fa-arrow-right"></i></a></td>
              </tr>`).join("")}
            </tbody>
          </table>
        </div>
      </div>

      <!-- Alertes + Activité -->
      <div class="grid lg:grid-cols-2 gap-6">
        <div class="card p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="font-700 text-white">Alertes Récentes</h3>
            <a href="/alertes" class="text-xs text-orange-400 hover:underline">Voir toutes</a>
          </div>
          <div class="space-y-3">
            ${[{icon:"fa-triangle-exclamation",color:"#ef4444",title:"Prix anormal détecté",desc:"Ciment à 18 000 FCFA/sac — marché: 12 000",time:"12 min"},{icon:"fa-boxes-stacked",color:"#eab308",title:"Stock de fer faible",desc:"Moins de 10% restant — Villa Zone 1",time:"1h"},{icon:"fa-truck",color:"#3b82f6",title:"Livraison en attente",desc:"50 sacs ciment à valider",time:"2h"}].map(a=>`
            <div class="flex items-start gap-3 p-3 rounded-xl border border-white/5 hover:border-white/10 cursor-pointer transition-all">
              <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style="background:${a.color}18">
                <i class="fas ${a.icon} text-sm" style="color:${a.color}"></i>
              </div>
              <div class="flex-1 min-w-0">
                <div class="flex items-center justify-between">
                  <div class="font-600 text-sm text-white truncate">${a.title}</div>
                  <div class="text-xs text-slate-600 flex-shrink-0 ml-2">${a.time}</div>
                </div>
                <div class="text-xs text-slate-500">${a.desc}</div>
              </div>
            </div>`).join("")}
          </div>
        </div>
        <div class="card p-6">
          <div class="flex items-center justify-between mb-4">
            <h3 class="font-700 text-white">Activité Récente</h3>
            <a href="/journal" class="text-xs text-orange-400 hover:underline">Journal</a>
          </div>
          <div class="space-y-4">
            ${[{user:"Ibrahim K.",action:"a validé une livraison",detail:"80 briques — Villa Zone 1",time:"14:32",color:"#22c55e"},{user:"Awa Traoré",action:"a soumis un rapport",detail:"Fondations 85% terminées",time:"13:15",color:"#3b82f6"},{user:"IA FasoChantier",action:"a détecté une anomalie",detail:"Prix du sable +40%",time:"11:02",color:"#a855f7"},{user:"${userName}",action:"s'est connecté",detail:"Depuis votre appareil",time:"Maintenant",color:"#f97316"}].map(a=>`
            <div class="flex items-start gap-3">
              <div class="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs font-700 text-white flex-shrink-0">
                ${a.user.split(" ").map(i=>i[0]).join("").slice(0,2).toUpperCase()}
              </div>
              <div class="flex-1">
                <div class="text-xs text-white"><span class="font-600">${a.user}</span> <span class="text-slate-400">${a.action}</span></div>
                <div class="text-xs text-slate-500">${a.detail}</div>
              </div>
              <div class="text-xs text-slate-600 flex-shrink-0">${a.time}</div>
            </div>`).join("")}
          </div>
        </div>
      </div>
    </main>
  </div>
</div>`)}function Ls(){return M("Mes Chantiers",`<div class="flex">${I("/chantiers")}<div class="main-content flex-1">${D("Mes Chantiers","12 chantiers au total — 7 actifs")}<main class="p-6 animate-fade-in">
  <div class="flex flex-wrap items-center gap-3 mb-6">
    <div class="flex gap-2">${["Tous","Actifs","En pause","Terminés"].map((e,t)=>`<button class="${t===0?"btn-primary":"btn-secondary"} text-sm py-2 px-4">${e}</button>`).join("")}</div>
    <button onclick="openModal('modal-nc')" class="ml-auto btn-primary"><i class="fas fa-plus"></i> Nouveau chantier</button>
  </div>
  <div class="grid md:grid-cols-2 xl:grid-cols-3 gap-5">
    ${[{id:1,name:"Villa Familiale — Zone 1",type:"Villa",loc:"Ouagadougou",prog:68,budget:"45 000 000",spent:"30 600 000",surface:220,risk:15,status:"active"},{id:2,name:"Maison R+1 — Pissy",type:"Maison",loc:"Ouagadougou",prog:35,budget:"28 000 000",spent:"9 800 000",surface:160,risk:42,status:"active"},{id:3,name:"Commerce Gounghin",type:"Commercial",loc:"Ouagadougou",prog:82,budget:"18 000 000",spent:"14 700 000",surface:80,risk:8,status:"active"},{id:4,name:"Villa Bobo-Dioulasso",type:"Villa",loc:"Bobo-Dioulasso",prog:20,budget:"54 000 000",spent:"10 800 000",surface:300,risk:71,status:"active"},{id:5,name:"Appartement Karpala",type:"Appartement",loc:"Ouagadougou",prog:100,budget:"22 000 000",spent:"21 500 000",surface:110,risk:5,status:"completed"},{id:6,name:"Villa Diaspora — Bassin",type:"Villa",loc:"Ouagadougou",prog:5,budget:"75 000 000",spent:"3 750 000",surface:400,risk:20,status:"planning"}].map(e=>`
    <div class="card p-5 cursor-pointer group" onclick="location.href='/chantier/${e.id}'">
      <div class="flex items-start justify-between mb-3">
        <div class="flex items-center gap-3">
          <div class="w-10 h-10 rounded-xl flex items-center justify-center" style="background:linear-gradient(135deg,rgba(249,115,22,.2),rgba(234,88,12,.15))">
            <i class="fas fa-hard-hat text-orange-400"></i>
          </div>
          <div>
            <div class="font-700 text-sm text-white group-hover:text-orange-400 transition-colors">${e.name}</div>
            <div class="text-xs text-slate-500">${e.type} · ${e.surface} m²</div>
          </div>
        </div>
        <span class="badge ${e.status==="active"?"badge-success":e.status==="completed"?"badge-info":"badge-orange"}">${e.status==="active"?"Actif":e.status==="completed"?"Terminé":"Planning"}</span>
      </div>
      <div class="flex items-center gap-1.5 text-xs text-slate-500 mb-3"><i class="fas fa-location-dot text-orange-500"></i>${e.loc}</div>
      <div class="mb-4">
        <div class="flex justify-between text-xs mb-1.5"><span class="text-slate-400">Avancement</span><span class="font-700 text-white">${e.prog}%</span></div>
        <div class="progress-bar h-2"><div class="progress-fill ${e.prog>80?"bg-green-500":e.prog>40?"bg-orange-500":"bg-blue-500"}" style="width:${e.prog}%"></div></div>
      </div>
      <div class="flex items-center justify-between bg-white/[0.03] rounded-lg p-3 mb-3">
        <div class="text-center"><div class="text-xs text-slate-500">Total</div><div class="text-sm font-700 text-white">${e.budget}</div></div>
        <div class="w-px h-8 bg-white/10"></div>
        <div class="text-center"><div class="text-xs text-slate-500">Dépensé</div><div class="text-sm font-700 text-orange-400">${e.spent}</div></div>
        <div class="w-px h-8 bg-white/10"></div>
        <div class="text-center"><div class="text-xs text-slate-500">Risque</div><div class="text-sm font-700 ${e.risk<30?"text-green-400":e.risk<60?"text-yellow-400":"text-red-400"}">${e.risk}/100</div></div>
      </div>
      <a href="/chantier/${e.id}" class="text-xs text-orange-400 hover:underline flex items-center gap-1">Voir détails <i class="fas fa-arrow-right text-xs"></i></a>
    </div>`).join("")}
  </div>
</main></div></div>
<div id="modal-nc" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,.7);backdrop-filter:blur(8px)">
  <div class="card w-full max-w-[560px] max-h-[90vh] overflow-y-auto animate-fade-in">
    <div class="flex items-center justify-between p-6 border-b border-white/5">
      <div><h2 class="font-700 text-white text-lg">Nouveau Chantier</h2><p class="text-xs text-slate-500">Remplissez les informations</p></div>
      <button onclick="closeModal('modal-nc')" class="text-slate-400 hover:text-white"><i class="fas fa-times"></i></button>
    </div>
    <div class="p-6 space-y-4">
      <div><label class="text-xs text-slate-400 mb-1 block">Nom du chantier *</label><input type="text" placeholder="Villa Familiale Zone 1" class="input"/></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-slate-400 mb-1 block">Type</label><select class="input"><option>Villa</option><option>Maison</option><option>Appartement</option><option>Commercial</option></select></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Pièces</label><input type="number" placeholder="5" class="input"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Surface (m²)</label><input type="number" placeholder="220" class="input"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Budget (FCFA)</label><input type="number" placeholder="45000000" class="input"/></div>
      </div>
      <div><label class="text-xs text-slate-400 mb-1 block">Localisation</label><input type="text" placeholder="Ouagadougou, Secteur 15" class="input"/></div>
      <div class="grid grid-cols-2 gap-3">
        <div><label class="text-xs text-slate-400 mb-1 block">Début prévu</label><input type="date" class="input"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Fin prévue</label><input type="date" class="input"/></div>
      </div>
      <div class="flex gap-3 pt-2">
        <button onclick="closeModal('modal-nc')" class="btn-secondary flex-1 justify-center">Annuler</button>
        <button onclick="showToast('Chantier créé avec succès !');closeModal('modal-nc')" class="btn-primary flex-1 justify-center"><i class="fas fa-plus"></i> Créer</button>
      </div>
    </div>
  </div>
</div>`)}function Ns(e){return M("Détail Chantier",`<div class="flex">${I("/chantiers")}<div class="main-content flex-1">${D("Villa Familiale — Zone 1","Chantier #"+e+" · Ouagadougou · Actif")}<main class="p-6 animate-fade-in space-y-6">
  <div class="card p-6" style="border-top:3px solid #f97316">
    <div class="flex flex-wrap items-start justify-between gap-4">
      <div>
        <div class="flex items-center gap-2 mb-1"><span class="badge badge-success">Actif</span><span class="badge badge-orange">Villa · 5 pièces · 220 m²</span></div>
        <h2 class="text-2xl font-800 text-white mb-1">Villa Familiale — Zone 1</h2>
        <div class="text-sm text-slate-400"><i class="fas fa-location-dot text-orange-500 mr-1"></i>Ouagadougou, Secteur 15 · Créé le 15 Jan 2025</div>
      </div>
      <div class="flex gap-2 flex-wrap">
        <button onclick="showToast('Rapport PDF généré !','success')" class="btn-secondary text-sm py-2 px-4"><i class="fas fa-file-pdf"></i> PDF</button>
        <button onclick="showToast('Photo ajoutée','success')" class="btn-primary text-sm py-2 px-4"><i class="fas fa-camera"></i> Photo</button>
      </div>
    </div>
    <div class="mt-4">
      <div class="flex justify-between text-sm mb-2"><span class="text-slate-400">Avancement global</span><span class="text-white font-700">68%</span></div>
      <div class="progress-bar h-3"><div class="progress-fill bg-gradient-to-r from-orange-600 to-orange-400" style="width:68%"></div></div>
    </div>
  </div>
  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
    ${[["Budget Total","45 000 000 FCFA","fa-wallet","#f97316"],["Dépensé","30 600 000 FCFA","fa-money-bill-wave","#ef4444"],["Restant","14 400 000 FCFA","fa-piggy-bank","#22c55e"],["Coût/m²","138 636 FCFA","fa-calculator","#3b82f6"]].map(([t,s,a,i])=>`
    <div class="card p-4">
      <div class="flex items-center gap-2 mb-2"><div class="w-8 h-8 rounded-lg flex items-center justify-center" style="background:${i}20"><i class="fas ${a} text-xs" style="color:${i}"></i></div><span class="text-xs text-slate-500">${t}</span></div>
      <div class="text-lg font-800 text-white">${s}</div>
    </div>`).join("")}
  </div>
  <div class="grid lg:grid-cols-2 gap-6">
    <div class="card p-5">
      <h3 class="font-700 text-white mb-4">Phases du Chantier</h3>
      <div class="space-y-3">
        ${[["Fondations",100,"#22c55e","done"],["Gros œuvre",80,"#f97316","active"],["Toiture/Dalle",45,"#3b82f6","active"],["Crépissage",0,"#6b7280","pending"],["Second œuvre",0,"#6b7280","pending"],["Finitions",0,"#6b7280","pending"]].map(([t,s,a,i])=>`
        <div class="flex items-center gap-3">
          <div class="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0" style="background:${a}20">
            <i class="fas ${i==="done"?"fa-check":i==="active"?"fa-circle-half-stroke":"fa-clock"} text-xs" style="color:${a}"></i>
          </div>
          <div class="flex-1">
            <div class="flex justify-between text-xs mb-1"><span class="text-slate-300 font-500">${t}</span><span class="font-700" style="color:${a}">${s}%</span></div>
            <div class="progress-bar h-1"><div class="progress-fill" style="width:${s}%;background:${a}"></div></div>
          </div>
        </div>`).join("")}
      </div>
    </div>
    <div class="card p-5">
      <div class="flex items-center justify-between mb-4"><h3 class="font-700 text-white">Stock Matériaux</h3><a href="/materiaux" class="text-xs text-orange-400">Gérer</a></div>
      <div class="space-y-3">
        ${[["Ciment","200 sacs","165 sacs","#f97316",!1],["Sable","15 m³","10 m³","#eab308",!1],["Gravier","12 m³","9 m³","#3b82f6",!1],["Fer HA12","2.5t","2.3t","#ef4444",!0],["Briques","3000","1800","#a855f7",!1]].map(([t,s,a,i,r])=>`
        <div class="flex items-center gap-3 p-2 rounded-lg ${r?"bg-red-500/5 border border-red-500/20":"bg-white/[0.02]"}">
          <i class="fas fa-cube text-xs flex-shrink-0" style="color:${i}"></i>
          <div class="flex-1">
            <div class="flex justify-between text-xs mb-0.5"><span class="text-slate-300 font-500">${t}</span><span class="text-slate-400">${a}/${s}</span></div>
            <div class="progress-bar h-1"><div class="progress-fill" style="width:${r?"92":"65"}%;background:${i}"></div></div>
          </div>
          ${r?'<i class="fas fa-exclamation-triangle text-red-400 text-xs flex-shrink-0"></i>':""}
        </div>`).join("")}
      </div>
    </div>
  </div>
</main></div></div>`)}function Bs(){return M("Budget & Finances",`<div class="flex">${I("/budget")}<div class="main-content flex-1">${D("Budget & Finances","Suivi intelligent de vos dépenses")}<main class="p-6 animate-fade-in space-y-6">
  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
    ${[["Budget Total","145 000 000","#f97316","fa-wallet"],["Dépensé","89 200 000","#ef4444","fa-arrow-up-from-bracket"],["Restant","55 800 000","#22c55e","fa-shield-check"],["Économisé","4 300 000","#a855f7","fa-piggy-bank"]].map(([e,t,s,a])=>`
    <div class="card p-4"><div class="flex items-center justify-between mb-2"><span class="text-xs text-slate-500">${e}</span><i class="fas ${a}" style="color:${s}"></i></div><div class="text-xl font-800 text-white">${t}</div><div class="text-xs mt-0.5" style="color:${s}">FCFA</div></div>`).join("")}
  </div>
  <div class="card p-6">
    <div class="flex items-center justify-between mb-4"><h3 class="font-700 text-white">Dépenses par Chantier</h3></div>
    <div class="space-y-3">
      ${[["Villa Zone 1",45,30.6,68,"#f97316"],["Maison R+1",28,9.8,35,"#3b82f6"],["Commerce Gounghin",18,14.7,82,"#22c55e"],["Villa Bobo",54,10.8,20,"#ef4444"]].map(([e,t,s,a,i])=>`
      <div>
        <div class="flex items-center justify-between mb-1 text-xs"><span class="text-slate-300 font-500">${e}</span><span class="text-slate-400">${s}M / ${t}M FCFA</span></div>
        <div class="flex items-center gap-2"><div class="progress-bar h-4 flex-1"><div class="progress-fill h-full rounded-md" style="width:${a}%;background:${i}"></div></div><span class="text-xs font-700" style="color:${i}">${a}%</span></div>
      </div>`).join("")}
    </div>
  </div>
  <div class="card p-6">
    <div class="flex items-center justify-between mb-5"><h3 class="font-700 text-white">Dépenses Récentes</h3><button onclick="openModal('modal-dep')" class="btn-primary text-sm py-2 px-4"><i class="fas fa-plus"></i> Ajouter</button></div>
    <table class="w-full">
      <thead><tr class="border-b border-white/5"><th class="text-left py-2 px-3 text-xs text-slate-500">DATE</th><th class="text-left py-2 px-3 text-xs text-slate-500">DESCRIPTION</th><th class="text-left py-2 px-3 text-xs text-slate-500">MONTANT</th><th class="text-left py-2 px-3 text-xs text-slate-500">STATUT</th><th class="py-2 px-3"></th></tr></thead>
      <tbody>
        ${[["16/05","Achat 50 sacs ciment","600 000","approved"],["15/05","Paiement maçons","1 200 000","pending"],["14/05","Fer à béton HA12","2 100 000","flagged"],["13/05","Transport gravier","280 000","approved"]].map(([e,t,s,a])=>`
        <tr class="table-row">
          <td class="py-3 px-3 text-xs text-slate-500">${e} mai</td>
          <td class="py-3 px-3 text-sm text-white font-500">${t}</td>
          <td class="py-3 px-3 text-sm font-700 text-white">${s} FCFA</td>
          <td class="py-3 px-3"><span class="badge ${a==="approved"?"badge-success":a==="pending"?"badge-warning":"badge-danger"}">${a==="approved"?"Approuvé":a==="pending"?"En attente":"Signalé"}</span></td>
          <td class="py-3 px-3">${a==="pending"?`<button onclick="showToast('Dépense approuvée','success')" class="text-xs text-green-400">Approuver</button>`:""}</td>
        </tr>`).join("")}
      </tbody>
    </table>
  </div>
</main></div></div>
<div id="modal-dep" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,.7);backdrop-filter:blur(8px)">
  <div class="card w-full max-w-md animate-fade-in">
    <div class="flex items-center justify-between p-5 border-b border-white/5"><h3 class="font-700 text-white">Nouvelle Dépense</h3><button onclick="closeModal('modal-dep')" class="text-slate-400 hover:text-white"><i class="fas fa-times"></i></button></div>
    <div class="p-5 space-y-4">
      <div><label class="text-xs text-slate-400 mb-1 block">Chantier</label><select class="input"><option>Villa Zone 1</option><option>Maison R+1</option></select></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Catégorie</label><select class="input"><option>Matériaux</option><option>Main d'oeuvre</option><option>Transport</option></select></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Description</label><input type="text" placeholder="Ex: Achat 50 sacs ciment" class="input"/></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Montant (FCFA)</label><input type="number" placeholder="600000" class="input"/></div>
      <div class="flex gap-3"><button onclick="closeModal('modal-dep')" class="btn-secondary flex-1 justify-center">Annuler</button><button onclick="showToast('Dépense enregistrée','success');closeModal('modal-dep')" class="btn-primary flex-1 justify-center">Enregistrer</button></div>
    </div>
  </div>
</div>`)}function Us(){return M("Approvisionnements",`<div class="flex">${I("/approvisionnements")}<div class="main-content flex-1">${D("Approvisionnements","Module Anti-Vol — Photo + GPS obligatoires")}<main class="p-6 animate-fade-in space-y-6">
  <div class="p-4 rounded-2xl flex items-center gap-4" style="background:linear-gradient(135deg,rgba(249,115,22,.12),rgba(234,88,12,.06));border:1px solid rgba(249,115,22,.25)">
    <div class="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 bg-orange-500/20"><i class="fas fa-shield-check text-orange-400 text-xl"></i></div>
    <div><div class="font-700 text-white">Module Anti-Vol Actif</div><div class="text-sm text-slate-400">Chaque livraison requiert une photo + géolocalisation + validation contrôleur. 48 livraisons sécurisées.</div></div>
    <div class="ml-auto text-right flex-shrink-0"><div class="text-2xl font-900 text-green-400">98%</div><div class="text-xs text-slate-500">Taux validation</div></div>
  </div>
  <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
    ${[["Total","48","fa-truck-ramp-box","#f97316"],["Validées","45","fa-circle-check","#22c55e"],["En attente","2","fa-clock","#eab308"],["Signalées","1","fa-flag","#ef4444"]].map(([e,t,s,a])=>`
    <div class="card p-4 flex items-center gap-3"><div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style="background:${a}20"><i class="fas ${s}" style="color:${a}"></i></div><div><div class="text-xl font-800 text-white">${t}</div><div class="text-xs text-slate-500">${e}</div></div></div>`).join("")}
  </div>
  <div class="card p-6">
    <div class="flex items-center justify-between mb-4"><h3 class="font-700 text-white">Historique Livraisons</h3><button onclick="openModal('modal-liv')" class="btn-primary text-sm py-2 px-4"><i class="fas fa-plus"></i> Enregistrer</button></div>
    <table class="w-full">
      <thead><tr class="border-b border-white/5"><th class="text-left py-2 px-3 text-xs text-slate-500">MATÉRIAU</th><th class="text-left py-2 px-3 text-xs text-slate-500">QTÉ</th><th class="text-left py-2 px-3 text-xs text-slate-500">PRIX UNIT.</th><th class="text-left py-2 px-3 text-xs text-slate-500">TOTAL</th><th class="text-left py-2 px-3 text-xs text-slate-500">📷</th><th class="text-left py-2 px-3 text-xs text-slate-500">📍</th><th class="text-left py-2 px-3 text-xs text-slate-500">STATUT</th></tr></thead>
      <tbody>
        ${[["Ciment Portland","50 sacs","12 000","600 000",!0,!0,"validated",!1],["Sable fin","5 m³","35 000","175 000",!0,!0,"validated",!1],["Fer HA12","500 kg","4 200","2 100 000",!0,!1,"flagged",!0],["Briques rouges","500 u","200","100 000",!0,!0,"validated",!1],["Ciment (susp.)","30 sacs","18 000","540 000",!1,!1,"pending",!0]].map(([e,t,s,a,i,r,n,l])=>`
        <tr class="table-row ${l?"bg-red-500/3":""}">
          <td class="py-3 px-3"><div class="font-600 text-sm text-white flex items-center gap-2">${l?'<i class="fas fa-exclamation-triangle text-red-400 text-xs"></i>':""}${e}</div></td>
          <td class="py-3 px-3 text-sm text-white">${t}</td>
          <td class="py-3 px-3 text-xs ${l?"text-red-400 font-700":"text-slate-300"}">${s} FCFA</td>
          <td class="py-3 px-3 text-sm font-700 text-white">${a} FCFA</td>
          <td class="py-3 px-3 text-center">${i?'<i class="fas fa-image text-green-400"></i>':'<i class="fas fa-image text-red-400/50"></i>'}</td>
          <td class="py-3 px-3 text-center">${r?'<i class="fas fa-location-dot text-green-400"></i>':'<i class="fas fa-location-dot text-red-400/50"></i>'}</td>
          <td class="py-3 px-3"><span class="badge ${n==="validated"?"badge-success":n==="pending"?"badge-warning":"badge-danger"}">${n==="validated"?"Validée":n==="pending"?"En attente":"Signalée"}</span></td>
        </tr>`).join("")}
      </tbody>
    </table>
  </div>
</main></div></div>
<div id="modal-liv" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,.7);backdrop-filter:blur(8px)">
  <div class="card w-full max-w-lg animate-fade-in max-h-[90vh] overflow-y-auto">
    <div class="flex items-center justify-between p-5 border-b border-white/5"><div><h3 class="font-700 text-white">Nouvelle Livraison</h3><p class="text-xs text-slate-500">Photo + GPS obligatoires</p></div><button onclick="closeModal('modal-liv')" class="text-slate-400 hover:text-white"><i class="fas fa-times"></i></button></div>
    <div class="p-5 space-y-4">
      <div class="grid grid-cols-2 gap-3">
        <div class="col-span-2"><label class="text-xs text-slate-400 mb-1 block">Matériau *</label><select class="input"><option>Ciment</option><option>Sable</option><option>Gravier</option><option>Fer à béton</option><option>Briques</option></select></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Quantité *</label><input type="number" class="input" placeholder="50"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Prix unitaire (FCFA)</label><input type="number" class="input" placeholder="12000"/></div>
      </div>
      <div><label class="text-xs text-slate-400 mb-1.5 block font-500">📸 Photo livraison <span class="text-red-400">*</span></label><div class="border-2 border-dashed border-orange-500/40 rounded-xl p-5 text-center cursor-pointer hover:border-orange-500/70 hover:bg-orange-500/5 transition-all"><i class="fas fa-camera text-3xl text-orange-500/60 mb-2 block"></i><div class="text-sm text-slate-300">Prendre ou uploader une photo</div></div></div>
      <div class="flex items-center gap-3 p-3 rounded-lg bg-green-500/5 border border-green-500/20"><i class="fas fa-location-dot text-green-400"></i><div class="text-xs text-slate-300">GPS automatique activé<br><span class="text-slate-500">Ouagadougou, 12.36° N, 1.54° W</span></div><span class="ml-auto badge badge-success">GPS OK</span></div>
      <div class="flex gap-3"><button onclick="closeModal('modal-liv')" class="btn-secondary flex-1 justify-center">Annuler</button><button onclick="showToast('Livraison enregistrée, en attente de validation');closeModal('modal-liv')" class="btn-primary flex-1 justify-center"><i class="fas fa-truck"></i> Enregistrer</button></div>
    </div>
  </div>
</div>`)}function qs(){return M("Matériaux & Stock",`<div class="flex">${I("/materiaux")}<div class="main-content flex-1">${D("Matériaux & Stock","Inventaire en temps réel")}<main class="p-6 animate-fade-in space-y-6">
  <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
    ${[["Ciment",35,200,"sacs","#f97316","fa-bag-shopping",!1],["Sable",5,15,"m³","#eab308","fa-hill-rockslide",!1],["Fer à béton",.2,2.5,"tonnes","#ef4444","fa-ruler-horizontal",!0],["Briques",1200,3e3,"u","#a855f7","fa-bricks",!1],["Gravier",3,12,"m³","#3b82f6","fa-circle-dot",!1],["Peinture",20,60,"bidons","#22c55e","fa-paintbrush",!1],["Bois",50,120,"ml","#a3855f","fa-tree",!1],["Carreaux",0,200,"m²","#6b7280","fa-th-large",!1]].map(([e,t,s,a,i,r,n])=>{const l=Math.round(Number(t)/Number(s)*100);return`<div class="card p-5 ${n?"border border-red-500/25":""}">
        ${n?'<div class="flex items-center gap-1 mb-2 text-xs text-red-400"><i class="fas fa-exclamation-triangle"></i> Stock critique !</div>':""}
        <div class="flex items-center gap-2 mb-3"><div class="w-9 h-9 rounded-lg flex items-center justify-center" style="background:${i}20"><i class="fas ${r} text-sm" style="color:${i}"></i></div><div class="font-700 text-sm text-white">${e}</div></div>
        <div class="text-2xl font-900 text-white mb-0.5">${t}<span class="text-sm font-400 text-slate-500 ml-1">${a}</span></div>
        <div class="text-xs text-slate-600 mb-3">sur ${s} ${a} reçus</div>
        <div class="progress-bar h-2"><div class="progress-fill" style="width:${l}%;background:${n?"#ef4444":i}"></div></div>
        <div class="flex items-center justify-between text-xs mt-2"><span style="color:${i}">${l}% restant</span></div>
      </div>`}).join("")}
  </div>
</main></div></div>`)}function Hs(){return M("Journal de Chantier",`<div class="flex">${I("/journal")}<div class="main-content flex-1">${D("Journal de Chantier","Historique chronologique")}<main class="p-6 animate-fade-in space-y-6">
  <div class="flex items-center justify-between"><div class="flex gap-2">${["Tous","Rapports","Incidents","Progrès"].map((e,t)=>`<button class="${t===0?"btn-primary":"btn-secondary"} text-sm py-2 px-4">${e}</button>`).join("")}</div><button onclick="openModal('modal-je')" class="btn-primary"><i class="fas fa-plus"></i> Nouvelle entrée</button></div>
  <div class="relative"><div class="absolute left-6 top-0 bottom-0 w-px bg-white/8"></div>
  <div class="space-y-5 pl-14">
    ${[{type:"progress",icon:"fa-chart-line",color:"#22c55e",title:"Rapport quotidien — 16 Mai",content:"Gros œuvre 3ème niveau en cours. 8 maçons sur le chantier. Pose des fers d'attente terminée côté Est.",author:"Ibrahim Kaboré",role:"Contrôleur",workers:8,pct:68,weather:"☀️"},{type:"incident",icon:"fa-triangle-exclamation",color:"#ef4444",title:"Incident — Pénurie ciment",content:"Stock de ciment épuisé. Travaux suspendus à 15h. Commande urgente passée chez CBMP. Livraison prévue demain.",author:"Awa Traoré",role:"Maçonne",workers:6,pct:null,weather:"⛅"},{type:"note",icon:"fa-sticky-note",color:"#a855f7",title:"Note propriétaire",content:"Suite à l'alerte de l'IA sur le prix du fer, j'ai contacté 3 fournisseurs. Changement de fournisseur validé.",author:"Kofi Sawadogo",role:"Propriétaire",workers:null,pct:null,weather:null}].map(e=>`
    <div class="relative">
      <div class="absolute -left-8 w-4 h-4 rounded-full border-2 border-dark-900" style="background:${e.color}"></div>
      <div class="card p-5">
        <div class="flex items-start justify-between mb-3">
          <div class="flex items-center gap-3">
            <div class="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0" style="background:${e.color}18"><i class="fas ${e.icon}" style="color:${e.color}"></i></div>
            <div><div class="font-700 text-white text-sm">${e.title}</div><div class="text-xs text-slate-500">2025</div></div>
          </div>
          <div class="flex items-center gap-2">${e.weather?`<span>${e.weather}</span>`:""} ${e.workers?`<span class="badge badge-info"><i class="fas fa-users mr-1"></i>${e.workers}</span>`:""} ${e.pct?`<span class="badge badge-orange">${e.pct}%</span>`:""}</div>
        </div>
        <p class="text-sm text-slate-300 leading-relaxed mb-3">${e.content}</p>
        <div class="flex items-center gap-2 pt-3 border-t border-white/5">
          <div class="w-6 h-6 rounded-full bg-orange-500/25 flex items-center justify-center text-xs font-700 text-orange-400">${e.author.split(" ").map(t=>t[0]).join("")}</div>
          <span class="text-xs text-slate-400">${e.author} · ${e.role}</span>
        </div>
      </div>
    </div>`).join("")}
  </div></div>
</main></div></div>
<div id="modal-je" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,.7);backdrop-filter:blur(8px)">
  <div class="card w-full max-w-lg animate-fade-in">
    <div class="flex items-center justify-between p-5 border-b border-white/5"><h3 class="font-700 text-white">Nouvelle entrée</h3><button onclick="closeModal('modal-je')" class="text-slate-400 hover:text-white"><i class="fas fa-times"></i></button></div>
    <div class="p-5 space-y-4">
      <div><label class="text-xs text-slate-400 mb-1 block">Type</label><select class="input"><option>Rapport quotidien</option><option>Incident</option><option>Progrès</option><option>Note</option></select></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Titre</label><input type="text" class="input" placeholder="Titre de l'entrée"/></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Contenu</label><textarea rows="4" class="input resize-none" placeholder="Décrivez ce qui s'est passé..."></textarea></div>
      <div class="grid grid-cols-2 gap-3"><div><label class="text-xs text-slate-400 mb-1 block">Ouvriers</label><input type="number" class="input" placeholder="8"/></div><div><label class="text-xs text-slate-400 mb-1 block">Avancement %</label><input type="number" class="input" placeholder="68" min="0" max="100"/></div></div>
      <div class="flex gap-3"><button onclick="closeModal('modal-je')" class="btn-secondary flex-1 justify-center">Annuler</button><button onclick="showToast('Entrée publiée dans le journal');closeModal('modal-je')" class="btn-primary flex-1 justify-center">Publier</button></div>
    </div>
  </div>
</div>`)}function zs(){return M("Alertes & IA",`<div class="flex">${I("/alertes")}<div class="main-content flex-1">${D("Alertes & IA","Détection intelligente des anomalies")}<main class="p-6 animate-fade-in space-y-6">
  <div class="grid lg:grid-cols-4 gap-4">
    <div class="card p-5 text-center" style="border:1px solid rgba(234,179,8,.3)"><div class="text-xs text-slate-500 mb-1">Score Risque Global</div><div class="text-5xl font-900 text-yellow-400 mb-1">24</div><div class="text-xs text-slate-500 mb-3">/100</div><div class="badge badge-warning mx-auto">RISQUE MODÉRÉ</div></div>
    ${[["Alertes critiques","1","#ef4444","fa-circle-xmark"],["Importantes","2","#eab308","fa-triangle-exclamation"],["Informations","5","#3b82f6","fa-circle-info"]].map(([e,t,s,a])=>`
    <div class="card p-5 flex flex-col justify-between"><div class="flex items-center justify-between mb-3"><span class="text-xs text-slate-500">${e}</span><i class="fas ${a}" style="color:${s}"></i></div><div class="text-4xl font-900" style="color:${s}">${t}</div><div class="text-xs text-slate-600">alertes actives</div></div>`).join("")}
  </div>
  <div class="space-y-3">
    ${[{sev:"critical",icon:"fa-triangle-exclamation",color:"#ef4444",title:"Prix anormal — Ciment",desc:"Ciment commandé à 18 000 FCFA/sac (marché: 12 000 FCFA). Différence: +38%. Anomalie détectée par l'IA.",project:"Villa Bobo-Dioulasso",time:"12 min",read:!1},{sev:"warning",icon:"fa-boxes-stacked",color:"#eab308",title:"Stock de fer critique",desc:"Fer HA12 à 200 kg restant. Seuil critique: 500 kg. Rupture estimée dans 48h au rythme actuel.",project:"Villa Zone 1",time:"1h",read:!1},{sev:"warning",icon:"fa-clock",color:"#f97316",title:"Livraison non validée 48h",desc:"Livraison de 30 sacs de ciment du 14/05 sans photo ni GPS. Fraude potentielle.",project:"Maison R+1 Pissy",time:"3h",read:!0},{sev:"info",icon:"fa-check-circle",color:"#22c55e",title:"Rapport hebdomadaire disponible",desc:"Votre rapport du 10-16 Mai 2025 est prêt. Téléchargez en PDF ou partagez par WhatsApp.",project:"Tous les chantiers",time:"8h",read:!0}].map(e=>`
    <div class="card p-5 ${e.read?"":"border-l-2"}">
      <div class="flex items-start gap-4">
        <div class="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style="background:${e.color}18;border:1px solid ${e.color}40"><i class="fas ${e.icon}" style="color:${e.color}"></i></div>
        <div class="flex-1 min-w-0">
          <div class="flex items-start justify-between gap-2 mb-1">
            <div class="font-700 text-white text-sm flex items-center gap-2">${e.read?"":`<div class="w-2 h-2 rounded-full flex-shrink-0" style="background:${e.color}"></div>`}${e.title}</div>
            <span class="text-xs text-slate-600 flex-shrink-0">${e.time}</span>
          </div>
          <p class="text-sm text-slate-400 leading-relaxed mb-2">${e.desc}</p>
          <div class="flex items-center justify-between">
            <div class="text-xs text-slate-500"><i class="fas fa-hard-hat text-orange-400 mr-1"></i>${e.project}</div>
            ${e.sev==="critical"?`<button onclick="showToast('Alerte traitée','success')" class="btn-secondary text-xs py-1.5 px-3">Traiter</button>`:e.sev==="warning"?`<button onclick="showToast('Commande passée','success')" class="btn-primary text-xs py-1.5 px-3">Agir</button>`:""}
          </div>
        </div>
      </div>
    </div>`).join("")}
  </div>
  <div class="card p-6" style="background:linear-gradient(135deg,rgba(168,85,247,.07),rgba(59,130,246,.07));border:1px solid rgba(168,85,247,.2)">
    <div class="flex items-center gap-3 mb-4"><div class="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center"><i class="fas fa-robot text-purple-400"></i></div><div><h3 class="font-700 text-white">Recommandations IA</h3><p class="text-xs text-slate-500">Générées automatiquement</p></div></div>
    <div class="grid md:grid-cols-3 gap-4">
      ${[["fa-magnifying-glass-dollar","#ef4444","Vérifier le fournisseur","Demandez une facture officielle pour le ciment à 18 000 FCFA/sac."],["fa-truck-fast","#eab308","Commander du fer urgent","Rupture de stock HA12 estimée dans 48h. Commandez 2 tonnes."],["fa-user-shield","#22c55e","Valider la livraison","30 sacs du 14/05 sans photo doivent être vérifiés physiquement."]].map(([e,t,s,a])=>`
      <div class="bg-white/[0.04] rounded-xl p-4"><div class="w-8 h-8 rounded-lg flex items-center justify-center mb-3" style="background:${t}20"><i class="fas ${e} text-xs" style="color:${t}"></i></div><div class="font-600 text-sm text-white mb-1">${s}</div><div class="text-xs text-slate-400 leading-relaxed">${a}</div></div>`).join("")}
    </div>
  </div>
</main></div></div>`)}function Vs(){return M("Rapports",`<div class="flex">${I("/rapports")}<div class="main-content flex-1">${D("Rapports","Génération et export")}<main class="p-6 animate-fade-in space-y-6">
  <div class="grid md:grid-cols-3 gap-5">
    ${[["fa-file-chart-column","#f97316","Rapport Financier","Dépenses, budget, projections, anomalies IA","PDF · Excel"],["fa-hard-hat","#3b82f6","Rapport de Chantier","Avancement, matériaux, incidents, journal","PDF"],["fa-truck-ramp-box","#22c55e","Rapport Anti-Vol","Livraisons, validations, score de risque","PDF · WhatsApp"]].map(([e,t,s,a,i])=>`
    <div class="card p-6 text-center"><div class="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center" style="background:${t}20"><i class="fas ${e} text-2xl" style="color:${t}"></i></div><h3 class="font-700 text-white mb-2">${s}</h3><p class="text-xs text-slate-500 leading-relaxed mb-4">${a}</p><div class="badge badge-info mb-4">${i}</div><button onclick="showToast('Rapport en cours de génération...')" class="btn-primary w-full justify-center"><i class="fas fa-download"></i> Générer</button></div>`).join("")}
  </div>
  <div class="card p-6">
    <h3 class="font-700 text-white mb-4">Rapports Récents</h3>
    <div class="space-y-3">
      ${[["Rapport Financier Hebdo — 10-16 Mai 2025","2.4 MB","PDF","16/05"],["Rapport Chantier — Villa Zone 1","5.1 MB","PDF","14/05"],["Rapport Anti-Vol — Avril 2025","1.8 MB","PDF","01/05"],["Rapport Financier Mensuel — Avril","3.2 MB","Excel","30/04"]].map(([e,t,s,a])=>`
    <div class="flex items-center gap-4 p-3 rounded-xl bg-white/[0.03] hover:bg-white/[0.06] cursor-pointer transition-all">
      <div class="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style="background:${s==="PDF"?"rgba(239,68,68,.15)":"rgba(34,197,94,.15)"}"><i class="fas fa-file-${s==="PDF"?"pdf":"excel"} text-lg" style="color:${s==="PDF"?"#ef4444":"#22c55e"}"></i></div>
      <div class="flex-1"><div class="font-600 text-sm text-white">${e}</div><div class="text-xs text-slate-500">${a} · ${t}</div></div>
      <div class="flex gap-2">
        <button onclick="showToast('Téléchargement démarré')" class="btn-secondary text-xs py-1.5 px-3"><i class="fas fa-download"></i></button>
        <button onclick="showToast('Partagé par WhatsApp','success')" class="btn-secondary text-xs py-1.5 px-3"><i class="fab fa-whatsapp text-green-400"></i></button>
      </div>
    </div>`).join("")}
    </div>
  </div>
</main></div></div>`)}function Gs(){return M("Abonnements",`<div class="flex">${I("/abonnements")}<div class="main-content flex-1">${D("Abonnements","Gérez votre formule FasoChantier")}<main class="p-6 animate-fade-in space-y-8">
  <div class="card p-6" style="border:1px solid rgba(249,115,22,.3)">
    <div class="flex items-start justify-between">
      <div><div class="badge badge-orange mb-2">FORMULE ACTUELLE</div><h2 class="text-2xl font-800 text-white flex items-center gap-2"><i class="fas fa-rocket text-orange-400"></i> Plan Pro</h2><p class="text-slate-400 text-sm mt-1">100 000 FCFA / chantier · Actif jusqu'au 31 Déc 2025</p></div>
      <div class="text-right"><div class="text-3xl font-900 grad-text">100k</div><div class="text-xs text-slate-500">FCFA / chantier</div></div>
    </div>
  </div>
  <div><h2 class="text-xl font-800 text-white mb-6 text-center">Choisissez votre formule</h2>
  <div class="grid md:grid-cols-3 gap-6">
    ${[{name:"Basic",price:"50 000",icon:"fa-seedling",color:"#94a3b8",features:["1 chantier","2 utilisateurs","Suivi budget","Module anti-vol","Photos illimitées"],popular:!1,current:!1},{name:"Pro",price:"100 000",icon:"fa-rocket",color:"#f97316",features:["10 chantiers","Illimité users","IA anomalies","Rapports PDF","Alertes WhatsApp","Mode diaspora"],popular:!0,current:!0},{name:"Entreprise",price:"Sur devis",icon:"fa-building",color:"#a855f7",features:["Chantiers illimités","API complète","Caméra IA","Support 24/7","Formation équipe"],popular:!1,current:!1}].map(e=>`
    <div class="card p-6 relative ${e.popular?"border-2":""}">
      ${e.popular?'<div class="absolute -top-3 left-1/2 -translate-x-1/2 badge badge-orange px-4 py-1">⭐ POPULAIRE</div>':""}
      ${e.current?'<div class="absolute top-4 right-4 badge badge-success">Actuel</div>':""}
      <div class="text-center mb-5"><div class="w-12 h-12 rounded-2xl mx-auto mb-3 flex items-center justify-center" style="background:${e.color}20"><i class="fas ${e.icon} text-xl" style="color:${e.color}"></i></div><h3 class="font-800 text-xl text-white">${e.name}</h3><div class="text-3xl font-900 mt-2" style="color:${e.color}">${e.price}</div><div class="text-xs text-slate-500">FCFA${e.price!=="Sur devis"?" / chantier":""}</div></div>
      <div class="space-y-2 mb-5">${e.features.map(t=>`<div class="flex items-center gap-2 text-sm"><i class="fas fa-check-circle text-xs" style="color:${e.color}"></i><span class="text-slate-300">${t}</span></div>`).join("")}</div>
      <button onclick="openModal('modal-pay')" class="${e.current?"btn-secondary":"btn-primary"} w-full justify-center">${e.current?'<i class="fas fa-check"></i> Plan actuel':e.price==="Sur devis"?'<i class="fas fa-phone"></i> Contacter':'<i class="fas fa-arrow-right"></i> Choisir'}</button>
    </div>`).join("")}
  </div></div>
  <div class="card p-5"><h3 class="font-700 text-white mb-4 text-center">Modes de paiement acceptés</h3><div class="flex flex-wrap items-center justify-center gap-4">${[["Orange Money","#ff6600"],["Moov Money","#0066cc"],["Wave","#1db7e7"],["MTN Money","#ffd700"],["Carte bancaire","#4f46e5"]].map(([e,t])=>`<div class="flex items-center gap-2 px-4 py-3 rounded-xl bg-white/5 border border-white/10"><i class="fas fa-mobile-screen" style="color:${t}"></i><span class="text-sm text-slate-300 font-500">${e}</span></div>`).join("")}</div></div>
</main></div></div>
<div id="modal-pay" class="hidden fixed inset-0 z-50 flex items-center justify-center p-4" style="background:rgba(0,0,0,.7);backdrop-filter:blur(8px)">
  <div class="card w-full max-w-md animate-fade-in">
    <div class="flex items-center justify-between p-5 border-b border-white/5"><h3 class="font-700 text-white">Paiement sécurisé</h3><button onclick="closeModal('modal-pay')" class="text-slate-400 hover:text-white"><i class="fas fa-times"></i></button></div>
    <div class="p-5 space-y-4">
      <div class="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4 text-center"><div class="font-700 text-white">Plan Pro — 1 Chantier</div><div class="text-2xl font-900 text-orange-400 mt-1">100 000 FCFA</div></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Mode de paiement</label><select class="input"><option>Orange Money</option><option>Moov Money</option><option>Wave</option><option>Carte bancaire</option></select></div>
      <div><label class="text-xs text-slate-400 mb-1 block">Numéro de téléphone</label><input type="tel" class="input" placeholder="70 00 00 00"/></div>
      <button onclick="showToast('Paiement initié ! Confirmez sur votre téléphone','info');closeModal('modal-pay')" class="btn-primary w-full justify-center py-3"><i class="fas fa-lock"></i> Payer 100 000 FCFA</button>
      <p class="text-xs text-slate-600 text-center">Paiement sécurisé · Remboursement sous 7 jours</p>
    </div>
  </div>
</div>`)}function Ks(){return M("Administration",`<div class="flex">${I("/admin")}<div class="main-content flex-1">${D("Administration","Gestion globale de la plateforme")}<main class="p-6 animate-fade-in space-y-6">
  <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
    ${[["Utilisateurs","2 847","fa-users","#f97316"],["Chantiers actifs","438","fa-hard-hat","#22c55e"],["Revenue mensuel","43.2M FCFA","fa-sack-dollar","#3b82f6"],["Abonnements","312","fa-crown","#a855f7"],["Rétention","94%","fa-heart","#ef4444"]].map(([e,t,s,a])=>`
    <div class="card p-4 text-center"><i class="fas ${s} text-2xl mb-2 block" style="color:${a}"></i><div class="text-xl font-900 text-white">${t}</div><div class="text-xs text-slate-500">${e}</div></div>`).join("")}
  </div>
  <div class="card p-6">
    <div class="flex items-center justify-between mb-4"><h3 class="font-700 text-white">Utilisateurs récents</h3><button onclick="showToast('Invitation envoyée','success')" class="btn-primary text-sm py-2 px-4"><i class="fas fa-user-plus"></i> Inviter</button></div>
    <table class="w-full">
      <thead><tr class="border-b border-white/5"><th class="text-left py-2 px-3 text-xs text-slate-500">UTILISATEUR</th><th class="text-left py-2 px-3 text-xs text-slate-500">RÔLE</th><th class="text-left py-2 px-3 text-xs text-slate-500">PLAN</th><th class="text-left py-2 px-3 text-xs text-slate-500">STATUT</th><th class="py-2 px-3"></th></tr></thead>
      <tbody>
        ${[["Kofi Sawadogo","Propriétaire","Pro",!0],["Fatou Ouédraogo","Propriétaire","Basic",!0],["Ibrahim Kaboré","Contrôleur","Basic",!0],["Awa Traoré","Propriétaire","Pro",!0],["Moussa Zongo","Tâcheron","—",!1]].map(([e,t,s,a])=>`
        <tr class="table-row">
          <td class="py-3 px-3"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded-full bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-xs font-700 text-white">${e.split(" ").map(i=>i[0]).join("").slice(0,2)}</div><div class="font-600 text-sm text-white">${e}</div></div></td>
          <td class="py-3 px-3 text-xs text-slate-400">${t}</td>
          <td class="py-3 px-3"><span class="badge ${s==="Pro"?"badge-orange":s==="Basic"?"badge-info":"badge-warning"}">${s}</span></td>
          <td class="py-3 px-3"><span class="badge ${a?"badge-success":"badge-danger"}">${a?"Actif":"Suspendu"}</span></td>
          <td class="py-3 px-3"><button onclick="showToast('Action effectuée','${a?"warning":"success"}')" class="text-xs ${a?"text-red-400":"text-green-400"}">${a?"Suspendre":"Réactiver"}</button></td>
        </tr>`).join("")}
      </tbody>
    </table>
  </div>
</main></div></div>`)}function Ws(e="",t="",s=""){const a={owner:"Propriétaire",controller:"Contrôleur",worker:"Tâcheron",admin:"Administrateur"},i=e.split(" ").map(r=>r[0]).join("").slice(0,2).toUpperCase()||"?";return M("Mon Profil",`<div class="flex">${I("/profil")}<div class="main-content flex-1">${D("Mon Profil","Paramètres et préférences")}<main class="p-6 animate-fade-in space-y-6">
  <div class="card p-6">
    <div class="flex flex-wrap items-center gap-6">
      <div class="relative">
        <div class="w-20 h-20 rounded-2xl bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center text-white text-2xl font-900 shadow-xl">${i}</div>
        <button class="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-orange-500 flex items-center justify-center text-white text-xs shadow-lg"><i class="fas fa-camera"></i></button>
      </div>
      <div>
        <h2 class="text-2xl font-800 text-white">${e||"Utilisateur"}</h2>
        <p class="text-slate-400 text-sm">${a[s]||s||"Utilisateur"} · <span class="text-orange-400">Plan Pro</span></p>
        <div class="text-xs text-slate-500 mt-1"><i class="fas fa-envelope mr-1"></i>${t}</div>
      </div>
      <div class="ml-auto"><button onclick="showToast('Profil enregistré !','success')" class="btn-primary"><i class="fas fa-save"></i> Enregistrer</button></div>
    </div>
  </div>
  <div class="grid lg:grid-cols-2 gap-6">
    <div class="card p-6">
      <h3 class="font-700 text-white mb-4">Informations Personnelles</h3>
      <div class="space-y-4">
        <div class="grid grid-cols-2 gap-3">
          <div><label class="text-xs text-slate-400 mb-1 block">Prénom</label><input type="text" value="${e.split(" ")[0]||""}" class="input"/></div>
          <div><label class="text-xs text-slate-400 mb-1 block">Nom</label><input type="text" value="${e.split(" ").slice(1).join(" ")||""}" class="input"/></div>
        </div>
        <div><label class="text-xs text-slate-400 mb-1 block">Email</label><input type="email" value="${t}" class="input"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Téléphone WhatsApp</label><input type="tel" class="input" placeholder="+226 70 00 00 00"/></div>
        <div><label class="text-xs text-slate-400 mb-1 block">Pays</label><select class="input"><option>🇧🇫 Burkina Faso</option><option>🇫🇷 France</option><option>🇺🇸 USA</option></select></div>
        <label class="flex items-center gap-2 cursor-pointer"><input type="checkbox" class="w-4 h-4 accent-orange-500"/><span class="text-sm text-slate-300">Mode Diaspora</span></label>
      </div>
    </div>
    <div class="space-y-5">
      <div class="card p-6">
        <h3 class="font-700 text-white mb-4">Notifications</h3>
        <div class="space-y-3">
          ${[["Alertes budget","checked"],["Livraisons à valider","checked"],["Anomalies IA","checked"],["Rapports hebdo","checked"],["Actualités",""]].map(([r,n])=>`
          <div class="flex items-center justify-between"><span class="text-sm text-slate-300">${r}</span><label class="relative inline-flex cursor-pointer"><input type="checkbox" ${n} class="sr-only peer"><div class="w-10 h-5 bg-white/10 rounded-full peer peer-checked:bg-orange-500 transition-colors"></div><div class="absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-5"></div></label></div>`).join("")}
        </div>
      </div>
      <div class="card p-6">
        <h3 class="font-700 text-white mb-4">Sécurité</h3>
        <div class="space-y-3">
          <button onclick="showToast('Lien de changement envoyé par email','info')" class="btn-secondary w-full justify-center text-sm"><i class="fas fa-lock"></i> Changer le mot de passe</button>
          <button onclick="showToast('2FA activée avec succès','success')" class="btn-secondary w-full justify-center text-sm"><i class="fas fa-mobile-screen"></i> Activer la 2FA</button>
          <button onclick="doLogout()" class="btn-secondary w-full justify-center text-sm text-red-400 hover:bg-red-500/10"><i class="fas fa-right-from-bracket"></i> Se déconnecter</button>
        </div>
      </div>
    </div>
  </div>
</main></div></div>
<script>async function doLogout(){await fetch('/api/auth/logout',{method:'POST'});window.location.href='/login?msg=logged_out';}<\/script>`)}const lt=new St,Js=Object.assign({"/src/index.tsx":y});let Mt=!1;for(const[,e]of Object.entries(Js))e&&(lt.all("*",t=>{let s;try{s=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,s)}),lt.notFound(t=>{let s;try{s=t.executionCtx}catch{}return e.fetch(t.req.raw,t.env,s)}),Mt=!0);if(!Mt)throw new Error("Can't import modules from ['/src/index.ts','/src/index.tsx','/app/server.ts']");export{lt as default};
